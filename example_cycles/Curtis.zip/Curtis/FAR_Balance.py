import numpy as np

from openmdao.api import ImplicitComponent

class FAR_Balance(ImplicitComponent):
    def setup(self):
        
        self.add_input('T4', val=3500, units='degR')
        
        self.add_input('T4max', val=3660, units='degR')
        
        self.add_input('T3', val=1600, units='degR')
        
        self.add_input('T3max', val=1750, units='degR')        
        
        self.add_input('NcMapVal', val=0.98)
        
        self.add_input('NcMapTgt', val=1.0)
        
        self.add_output('FAR', val=.034)
        
        self.declare_partials('FAR', ['T3', 'T4','NcMapVal'], method='fd')
        
    def apply_nonlinear(self, inputs, outputs, residuals):
        
        T4 = inputs['T4']
        T4max = inputs['T4max']

        T3 = inputs['T3']
        T3max = inputs['T3max']
        
        NcMapVal = inputs['NcMapVal']
        NcMapTgt = inputs['NcMapTgt']
        
        if T4 >= T4max:
            
            if T3 >= T3max:
                residuals['FAR'] = T3 - T3max
                
            else:
            residuals['FAR'] = T4 - T4max
        
        elif T3 >= T3max:
            residuals['FAR'] = T3 - T3max
        
        else:
            residuals['FAR'] = NcMapVal - NcMapTgt
            