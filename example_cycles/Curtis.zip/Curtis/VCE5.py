import sys

import numpy as np

import openmdao.api as om

import pycycle.api as pyc


class VCE5(om.Group):

    def initialize(self):
        self.options.declare('design', default=True,
                              desc='Switch between on-design and off-design calculation.')
        self.options.declare('cooling', default=True, 
                             desc='If True, calculate cooling flows')

    def setup(self):

        thermo_spec = pyc.species_data.janaf
        design = self.options['design']
        cooling = self.options['cooling']

        self.add_subsystem('fc', pyc.FlightConditions(thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('inlet', pyc.ComplexInlet(design=design, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('vcesplitter', pyc.Splitter(design=design, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('duct1', pyc.Duct(design=design, expMN=1.75, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('fan', pyc.Compressor(map_data=pyc.FanMap, design=design, thermo_data=thermo_spec, elements=pyc.AIR_MIX, 
                                                 map_extrap=True), promotes_inputs=[('Nmech','LP_Nmech')])
        self.add_subsystem('duct21', pyc.Duct(design=design, expMN=1.75, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        
        self.add_subsystem('splitter', pyc.Splitter(design=design, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('ductbypassa', pyc.Duct(design=design, expMN=1.75, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('ductcore', pyc.Duct(design=design, expMN=1.75, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        
        #ENGINE CORE
        self.add_subsystem('hpc', pyc.Compressor(map_data=pyc.HPCMap, design=design, thermo_data=thermo_spec, elements=pyc.AIR_MIX,
                                        bleed_names=['bleed_hpc42','bleed_hpc49','bleed_hpc1', 'bleed_hpc2'], map_extrap=True),promotes_inputs=[('Nmech','HP_Nmech')])
        self.add_subsystem('bleeds', pyc.BleedOut(design=design, bleed_names=['cust','bleed_srce1', 'bleed_srce2']))
        self.add_subsystem('duct3', pyc.Duct(design=design, expMN=1.75, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('combustor', pyc.Combustor(design=design,thermo_data=thermo_spec,
                                        inflow_elements=pyc.AIR_MIX,
                                        air_fuel_elements=pyc.AIR_FUEL_MIX,
                                        fuel_type='Jet-A(g)'))
        self.add_subsystem('duct40', pyc.Duct(design=design, expMN=1.75, thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))
        self.add_subsystem('hpt', pyc.Turbine(map_data=pyc.HPTMap, design=design, thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX,
                                        bleed_names=['bleed_srce1','bleed_srce2', 'bleed_42'], map_extrap=True),promotes_inputs=[('Nmech','HP_Nmech')])
        self.add_subsystem('duct42', pyc.Duct(design=design, expMN=1.75, thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))
        self.add_subsystem('lpt', pyc.Turbine(map_data=pyc.LPTMap, design=design, thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX,
                                        bleed_names=['bleed_lpt1','bleed_lpt2', 'bleed_49'], map_extrap=True),promotes_inputs=[('Nmech','LP_Nmech')])
        
        #MIXER MERGE
        self.add_subsystem('duct7', pyc.Duct(design=design, expMN=1.75, thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))
        self.add_subsystem('ductbypassb', pyc.Duct(design=design, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('mixer', pyc.Mixer(design=design, thermo_data=thermo_spec, designed_stream=1, 
                                          Fl_I1_elements=pyc.AIR_FUEL_MIX, Fl_I2_elements=pyc.AIR_MIX))
        
        #AFTERBURNER
        self.add_subsystem('duct8', pyc.Duct(design=design, expMN=1.75, thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))
        self.add_subsystem('afterburner', pyc.Combustor(design=design, thermo_data=thermo_spec,inflow_elements=pyc.AIR_FUEL_MIX,
                                            air_fuel_elements=pyc.AIR_FUEL_MIX, fuel_type='Jet-A(g)'))
        self.add_subsystem('nozzle', pyc.Nozzle(nozzType='CD', lossCoef='Cv', thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))
        
        self.add_subsystem('lp_shaft', pyc.Shaft(num_ports=3),promotes_inputs=[('Nmech','LP_Nmech')])
        self.add_subsystem('hp_shaft', pyc.Shaft(num_ports=2),promotes_inputs=[('Nmech','HP_Nmech')])
        
        #VCE BYPASS
        self.add_subsystem('duct1a', pyc.Duct(design=design, expMN=1.75, thermo_data=thermo_spec, elements=pyc.AIR_MIX))   
        self.add_subsystem('vcefan', pyc.Compressor(map_data=pyc.FanMap, design=design, thermo_data=thermo_spec, elements=pyc.AIR_MIX, 
                                                 map_extrap=True), promotes_inputs=[('Nmech','LP_Nmech')])
        self.add_subsystem('vcebypassa', pyc.Duct(design=design, expMN=1.75, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('vcebypassb', pyc.Duct(design=design, expMN=1.75, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('vceaugmentor', pyc.Combustor(design=design, thermo_data=thermo_spec, inflow_elements=pyc.AIR_MIX,
                                            air_fuel_elements=pyc.AIR_FUEL_MIX, fuel_type='Jet-A(g)'))
        self.add_subsystem('vcenozzle', pyc.Nozzle(nozzType='CV', lossCoef='Cv', thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))
        

        #PERFIRMANCE MODULE
        self.add_subsystem('perf', pyc.Performance(num_nozzles=2, num_burners=3))

        #OPR
        self.connect('inlet.Fl_O:tot:P', 'perf.Pt2')
        self.connect('hpc.Fl_O:tot:P', 'perf.Pt3')
        
        # FUEL BURN
        self.connect('combustor.Wfuel', 'perf.Wfuel_0')
        self.connect('afterburner.Wfuel', 'perf.Wfuel_1')
        self.connect('vceaugmentor.Wfuel', 'perf.Wfuel_2')
        
        #Net Force
        self.connect('inlet.F_ram', 'perf.ram_drag')
        self.connect('nozzle.Fg', 'perf.Fg_0')
        self.connect('vcenozzle.Fg', 'perf.Fg_1')

        self.connect('fan.trq', 'lp_shaft.trq_0')
        self.connect('vcefan.trq', 'lp_shaft.trq_1')
        self.connect('lpt.trq', 'lp_shaft.trq_2')
        self.connect('hpc.trq', 'hp_shaft.trq_0')
        self.connect('hpt.trq', 'hp_shaft.trq_1')
        self.connect('fc.Fl_O:stat:P', 'nozzle.Ps_exhaust')
        self.connect('fc.Fl_O:stat:P', 'vcenozzle.Ps_exhaust')

        #
        #FLOW STATION CONNECT
        #
        pyc.connect_flow(self, 'fc.Fl_O', 'inlet.Fl_I', connect_w=False)
        pyc.connect_flow(self, 'inlet.Fl_O', 'vcesplitter.Fl_I')
        pyc.connect_flow(self, 'vcesplitter.Fl_O1', 'duct1.Fl_I')
        pyc.connect_flow(self, 'vcesplitter.Fl_O2', 'duct1a.Fl_I')
       
        pyc.connect_flow(self, 'duct1.Fl_O', 'fan.Fl_I')
        pyc.connect_flow(self, 'fan.Fl_O', 'duct21.Fl_I')
        pyc.connect_flow(self, 'duct21.Fl_O', 'splitter.Fl_I')
        pyc.connect_flow(self, 'splitter.Fl_O1', 'ductcore.Fl_I')
        pyc.connect_flow(self, 'splitter.Fl_O2', 'ductbypassa.Fl_I')
        
        pyc.connect_flow(self, 'ductcore.Fl_O', 'hpc.Fl_I')
        pyc.connect_flow(self, 'hpc.Fl_O', 'bleeds.Fl_I')
        pyc.connect_flow(self, 'bleeds.Fl_O', 'duct3.Fl_I')
        pyc.connect_flow(self, 'duct3.Fl_O', 'combustor.Fl_I')
        pyc.connect_flow(self, 'combustor.Fl_O', 'duct40.Fl_I') 
        pyc.connect_flow(self, 'duct40.Fl_O', 'hpt.Fl_I')
        pyc.connect_flow(self, 'hpt.Fl_O', 'duct42.Fl_I')
        pyc.connect_flow(self, 'duct42.Fl_O', 'lpt.Fl_I')
        pyc.connect_flow(self, 'lpt.Fl_O', 'duct7.Fl_I')

        pyc.connect_flow(self, 'ductbypassa.Fl_O', 'ductbypassb.Fl_I')
        
        pyc.connect_flow(self, 'duct7.Fl_O', 'mixer.Fl_I2')
        pyc.connect_flow(self, 'ductbypassb.Fl_O', 'mixer.Fl_I1')
        
        pyc.connect_flow(self, 'mixer.Fl_O', 'duct8.Fl_I')
        pyc.connect_flow(self, 'duct8.Fl_O', 'afterburner.Fl_I')
        pyc.connect_flow(self, 'afterburner.Fl_O', 'nozzle.Fl_I')
        
        pyc.connect_flow(self, 'duct1a.Fl_O', 'vcefan.Fl_I')
        pyc.connect_flow(self, 'vcefan.Fl_O', 'vcebypassa.Fl_I')
        pyc.connect_flow(self, 'vcebypassa.Fl_O', 'vcebypassb.Fl_I')
        pyc.connect_flow(self, 'vcebypassb.Fl_O', 'vceaugmentor.Fl_I')
        pyc.connect_flow(self, 'vceaugmentor.Fl_O', 'vcenozzle.Fl_I')        
        
        #
        #Cooling flow connections
        #
        pyc.connect_flow(self, 'hpc.bleed_hpc1', 'lpt.bleed_lpt1', connect_stat=False)
        pyc.connect_flow(self, 'hpc.bleed_hpc2', 'lpt.bleed_lpt2', connect_stat=False)
        pyc.connect_flow(self, 'hpc.bleed_hpc49', 'lpt.bleed_49', connect_stat=False)
        pyc.connect_flow(self, 'hpc.bleed_hpc42', 'hpt.bleed_42', connect_stat=False)
        pyc.connect_flow(self, 'bleeds.bleed_srce1', 'hpt.bleed_srce1', connect_stat=False)
        pyc.connect_flow(self, 'bleeds.bleed_srce2', 'hpt.bleed_srce2', connect_stat=False)

        
        add_order = []
        
        balance = self.add_subsystem('balance', om.BalanceComp())
        if design:
            
            balance.add_balance('BPR', eq_units=None, lower=0.1, val=4)
            self.connect('balance.BPR', 'splitter.BPR')
            self.connect('mixer.ER', 'balance.lhs:BPR') 
            
            balance.add_balance('FAR', eq_units='degR', lower=1e-4, val=.032)
            self.connect('balance.FAR', 'combustor.Fl_I:FAR')
            self.connect('combustor.Fl_O:tot:T', 'balance.lhs:FAR')
            
            #balance.add_balance('FAR_AB', eq_units='degR', lower=1e-4, val=0.032)
            #self.connect('balance.FAR_AB', 'afterburner.Fl_I:FAR')
            #self.connect('afterburner.Fl_O:tot:T', 'balance.lhs:FAR_AB')
            
            #balance.add_balance('hpc_PR', lower=1.001, upper=28)
            #self.connect('balance.hpc_PR', 'hpc.PR')
            #self.connect('perf.OPR', 'balance.lhs:hpc_PR')
            
            balance.add_balance('lpt_PR', val=1.5, lower=1.001, upper=8,
                                eq_units='hp', use_mult=True, mult_val=-1)
            self.connect('balance.lpt_PR', 'lpt.PR')
            self.connect('lp_shaft.pwr_in_real', 'balance.lhs:lpt_PR')
            self.connect('lp_shaft.pwr_out_real', 'balance.rhs:lpt_PR')

            balance.add_balance('hpt_PR', val=1.5, lower=1.001, upper=8,
                                eq_units='hp', use_mult=True, mult_val=-1)
            self.connect('balance.hpt_PR', 'hpt.PR')
            self.connect('hp_shaft.pwr_in_real', 'balance.lhs:hpt_PR')
            self.connect('hp_shaft.pwr_out_real', 'balance.rhs:hpt_PR')
            
            # 
            # Efficiencies
            # 
            balance.add_balance('fan_eff', val=0.9689, lower=0.01, upper=1.0, units=None, eq_units=None)
            self.connect('balance.fan_eff', 'fan.eff')
            self.connect('fan.eff_poly', 'balance.lhs:fan_eff')

            balance.add_balance('hpc_eff', val=0.8470, lower=0.01, upper=1.0, units=None, eq_units=None)
            self.connect('balance.hpc_eff', 'hpc.eff')
            self.connect('hpc.eff_poly', 'balance.lhs:hpc_eff')

            balance.add_balance('hpt_eff', val=0.9226, lower=0.01, upper=1.0, units=None, eq_units=None)
            self.connect('balance.hpt_eff', 'hpt.eff')
            self.connect('hpt.eff_poly', 'balance.lhs:hpt_eff')

            balance.add_balance('lpt_eff', val=0.9401, lower=0.01, upper=1.0, units=None, eq_units=None)
            self.connect('balance.lpt_eff', 'lpt.eff')
            self.connect('lpt.eff_poly', 'balance.lhs:lpt_eff')

        else:

            balance.add_balance('FAR', val=0.032, lower=1e-4, upper=0.06,eq_units='degR')
            self.connect('balance.FAR', 'combustor.Fl_I:FAR')
            self.connect('combustor.Fl_O:tot:T', 'balance.lhs:FAR')

            balance.add_balance('W', units='lbm/s', lower=10., upper=1000., rhs_val=2.2)
            self.connect('balance.W', 'inlet.Fl_I:stat:W')
            self.connect('fan.map.RlineMap', 'balance.lhs:W')

            #balance.add_balance('FAR_AB', eq_units='degR', lower=1e-4, val=0.032)
            #self.connect('balance.FAR_AB', 'afterburner.Fl_I:FAR')
            #self.connect('afterburner.Fl_O:tot:T', 'balance.lhs:FAR_AB')           

            balance.add_balance('BPR', lower=0.3, rhs_val=2.05)
            self.connect('balance.BPR', 'splitter.BPR')
            self.connect('hpc.map.RlineMap', 'balance.lhs:BPR')
            
            balance.add_balance('vce_BPR', lower=0.1, upper=0.5, eq_units='inch**2')
            self.connect('balance.vce_BPR', 'vcesplitter.BPR')
            self.connect('vcenozzle.Throat:stat:area', 'balance.lhs:vce_BPR')

            balance.add_balance('lp_Nmech', val=1.5, units='rpm', lower=500., eq_units='hp', use_mult=True, mult_val=-1)
            self.connect('balance.lp_Nmech', 'LP_Nmech')
            self.connect('lp_shaft.pwr_in_real', 'balance.lhs:lp_Nmech')
            self.connect('lp_shaft.pwr_out_real', 'balance.rhs:lp_Nmech')

            balance.add_balance('hp_Nmech', val=1.5, units='rpm', lower=500., eq_units='hp', use_mult=True, mult_val=-1)
            self.connect('balance.hp_Nmech', 'HP_Nmech')
            self.connect('hp_shaft.pwr_in_real', 'balance.lhs:hp_Nmech')
            self.connect('hp_shaft.pwr_out_real', 'balance.rhs:hp_Nmech')



        if cooling:
            #
            # HIGH PRESSURE TURBINE COOLING
            #
            self.add_subsystem('hpt_cooling', pyc.TurbineCooling(n_stages=2, thermo_data=pyc.species_data.janaf, owns_x_factor=True, T_metal=2350.))
            self.add_subsystem('hpt_chargable', pyc.CombineCooling(n_ins=3))
            
            pyc.connect_flow(self, 'bleeds.bleed_srce1', 'hpt_cooling.Fl_cool', connect_stat=False)
            pyc.connect_flow(self, 'combustor.Fl_O', 'hpt_cooling.Fl_turb_I')
            pyc.connect_flow(self, 'hpt.Fl_O', 'hpt_cooling.Fl_turb_O')
            
            self.connect('hpt_cooling.row_1.W_cool', 'hpt_chargable.W_1')
            self.connect('hpt_cooling.row_2.W_cool', 'hpt_chargable.W_2')
            self.connect('hpt_cooling.row_3.W_cool', 'hpt_chargable.W_3')
            self.connect('hpt.power', 'hpt_cooling.turb_pwr')
            
            balance.add_balance('hpt_nochrg_cool_frac', val=0.06366, lower=0.01, upper=0.2, eq_units='lbm/s')
            self.connect('balance.hpt_nochrg_cool_frac', 'bleeds.bleed_srce1:frac_W')
            self.connect('bleeds.bleed_srce1:stat:W', 'balance.lhs:hpt_nochrg_cool_frac')
            self.connect('hpt_cooling.row_0.W_cool', 'balance.rhs:hpt_nochrg_cool_frac')
            
            balance.add_balance('hpt_chrg_cool_frac', val=0.07037, lower=0.01, upper=0.2, eq_units='lbm/s')
            self.connect('balance.hpt_chrg_cool_frac', 'bleeds.bleed_srce2:frac_W')
            self.connect('bleeds.bleed_srce2:stat:W', 'balance.lhs:hpt_chrg_cool_frac')
            self.connect('hpt_chargable.W_cool', 'balance.rhs:hpt_chrg_cool_frac')
            
            #
            # LOW PRESSURE TURBINE COOLING
            #
            self.add_subsystem('lpt_cooling', pyc.TurbineCooling(n_stages=2, thermo_data=pyc.species_data.janaf, T_metal=2350.))
            self.add_subsystem('lpt_chargable', pyc.CombineCooling(n_ins=3))
            
            pyc.connect_flow(self, 'hpc.bleed_hpc1', 'lpt_cooling.Fl_cool', connect_stat=False)
            pyc.connect_flow(self, 'duct42.Fl_O', 'lpt_cooling.Fl_turb_I')
            pyc.connect_flow(self, 'lpt.Fl_O', 'lpt_cooling.Fl_turb_O')
                
            self.connect('lpt_cooling.row_1.W_cool', 'lpt_chargable.W_1')
            self.connect('lpt_cooling.row_2.W_cool', 'lpt_chargable.W_2')
            self.connect('lpt_cooling.row_3.W_cool', 'lpt_chargable.W_3')
            self.connect('lpt.power', 'lpt_cooling.turb_pwr')
            
            balance.add_balance('lpt_nochrg_cool_frac', val=0.06366, lower=0.00001, upper=0.2, eq_units='lbm/s')
            self.connect('balance.lpt_nochrg_cool_frac', 'hpc.bleed_hpc1:frac_W')
            self.connect('hpc.bleed_hpc1:stat:W', 'balance.lhs:lpt_nochrg_cool_frac')
            self.connect('lpt_cooling.row_0.W_cool', 'balance.rhs:lpt_nochrg_cool_frac')
            
            balance.add_balance('lpt_chrg_cool_frac', val=0.07037, lower=0.00001, upper=0.2, eq_units='lbm/s')
            self.connect('balance.lpt_chrg_cool_frac', 'hpc.bleed_hpc2:frac_W')
            self.connect('hpc.bleed_hpc2:stat:W', 'balance.lhs:lpt_chrg_cool_frac')
            self.connect('lpt_chargable.W_cool', 'balance.rhs:lpt_chrg_cool_frac')
            
            add_order = add_order + ['hpt_cooling', 'hpt_chargable', 'lpt_cooling', 'lpt_chargable']
        
        
        main_order = ['balance', 'fc', 'inlet','vcesplitter', 'duct1', 'fan', 'duct21', 'splitter', 'ductbypassa', 'ductcore', 'hpc',
                        'bleeds', 'duct3', 'combustor', 'duct40', 'hpt', 'duct42', 'lpt', 'duct7', 
                        'ductbypassb', 'mixer', 'duct8', 'afterburner', 'nozzle','duct1a', 'vcefan', 
                        'vcebypassa', 'vcebypassb', 'vceaugmentor', 'vcenozzle','lp_shaft', 'hp_shaft','perf']
        
        self.set_order(main_order + add_order)

        
        newton = self.nonlinear_solver = om.NewtonSolver()
        newton.options['atol'] = 1e-8
        newton.options['rtol'] = 1e-8
        newton.options['iprint'] = 2
        newton.options['maxiter'] = 15
        newton.options['solve_subsystems'] = True
        newton.options['max_sub_solves'] = 100
        newton.options['reraise_child_analysiserror'] = False
        # ls = newton.linesearch = BoundsEnforceLS()
        ls = newton.linesearch = om.ArmijoGoldsteinLS()
        ls.options['maxiter'] = 5
        ls.options['bound_enforcement'] = 'scalar'
        #ls.options['iprint'] = -1

        self.linear_solver = om.DirectSolver(assemble_jac=True)


def viewer(prob, pt, file=sys.stdout):
    """
    print a report of all the relevant cycle properties
    """

    if pt == 'DESIGN':
        MN = prob['DESIGN.fc.Fl_O:stat:MN']
        LPT_PR = prob['DESIGN.balance.lpt_PR']
        HPT_PR = prob['DESIGN.balance.hpt_PR']
        FAR = prob['DESIGN.balance.FAR']
    else:
        MN = prob[pt+'.fc.Fl_O:stat:MN']
        LPT_PR = prob[pt+'.lpt.PR']
        HPT_PR = prob[pt+'.hpt.PR']
        FAR = prob[pt+'.balance.FAR']

    print(file=file, flush=True)
    print(file=file, flush=True)
    print(file=file, flush=True)
    print("----------------------------------------------------------------------------", file=file, flush=True)
    print("                              POINT:", pt, file=file, flush=True)
    print("----------------------------------------------------------------------------", file=file, flush=True)
    print("                       PERFORMANCE CHARACTERISTICS", file=file, flush=True)
    print("    Mach      Alt       W      Fn      Fg    Fram     OPR     TSFC      BPR ", file=file, flush=True)
    print(" %7.5f  %7.1f %7.3f %7.1f %7.1f %7.1f %7.3f  %7.5f  %7.3f" %(MN, prob[pt+'.fc.alt'],prob[pt+'.inlet.Fl_O:stat:W'],prob[pt+'.perf.Fn'],prob[pt+'.perf.Fg'],prob[pt+'.inlet.F_ram'],prob[pt+'.perf.OPR'],prob[pt+'.perf.TSFC'], prob[pt+'.splitter.BPR']), file=file, flush=True)


    fs_names = ['fc.Fl_O', 'inlet.Fl_O', 'vcesplitter.Fl_O1', 'vcesplitter.Fl_O2', 'duct1.Fl_O', 'fan.Fl_O', 'duct21.Fl_O', 'splitter.Fl_O1', 'splitter.Fl_O2',
                'ductbypassa.Fl_O', 'ductcore.Fl_O','hpc.Fl_O', 'bleeds.Fl_O', 'duct3.Fl_O', 'combustor.Fl_O','duct40.Fl_O', 'hpt.Fl_O',
                'duct42.Fl_O', 'lpt.Fl_O', 'duct7.Fl_O', 'ductbypassb.Fl_O', 'mixer.Fl_O', 'duct8.Fl_O', 'afterburner.Fl_O', 'nozzle.Fl_O',
                'duct1a.Fl_O', 'vcefan.Fl_O', 'vcebypassa.Fl_O', 'vcebypassb.Fl_O', 'vceaugmentor.Fl_O', 'vcenozzle.Fl_O']
    
    fs_full_names = [f'{pt}.{fs}' for fs in fs_names]
    pyc.print_flow_station(prob, fs_full_names, file=file)

    comp_names = ['fan','vcefan', 'hpc']
    comp_full_names = [f'{pt}.{c}' for c in comp_names]
    pyc.print_compressor(prob, comp_full_names, file=file)

    burn_names = ['combustor', 'afterburner', 'vceaugmentor']
    burn_full_names = [f'{pt}.{b}' for b in burn_names]
    pyc.print_burner(prob, burn_full_names, file=file)

    turb_names = ['hpt', 'lpt']
    turb_full_names = [f'{pt}.{t}' for t in turb_names]
    pyc.print_turbine(prob, turb_full_names, file=file)

    noz_names = ['nozzle', 'vcenozzle']
    noz_full_names = [f'{pt}.{n}' for n in noz_names]
    pyc.print_nozzle(prob, noz_full_names, file=file)
    
    pyc.print_mixer(prob, [pt+'.mixer'])

    shaft_names = ['hp_shaft', 'lp_shaft']
    shaft_full_names = [f'{pt}.{s}' for s in shaft_names]
    pyc.print_shaft(prob, shaft_full_names, file=file)

    bleed_names = ['hpc', 'bleeds']
    bleed_full_names = [f'{pt}.{b}' for b in bleed_names]
    pyc.print_bleed(prob, bleed_full_names, file=file)

if __name__ == "__main__":

    import time

    prob = om.Problem()

    des_vars = prob.model.add_subsystem('des_vars',
                                        om.IndepVarComp(), promotes=["*"])

    # FOR DESIGN
    des_vars.add_output('alt', .01, units='ft'),
    des_vars.add_output('dTs', 18., units='degR')
    des_vars.add_output('MN', 0.2),
    des_vars.add_output('T4max', 3660, units='degR'),
    des_vars.add_output('W', 570.0, units='lbm/s')
    #des_vars.add_output('Fn_des', 45000, units='lbf'),
    des_vars.add_output('OPR_des', 40.0)
    #des_vars.add_output('ABTmax', 3660.0, units='degR')
    #des_vars.add_output('afterburner:FAR', 0.03)
    des_vars.add_output('mix_ER', 1.025)
    des_vars.add_output('fan:SMW', 25)
    des_vars.add_output('hpc:SMW', 28)
    
    des_vars.add_output('inlet:etaBase', 0.998),
    des_vars.add_output('duct1:dPqP', 0.0),
    des_vars.add_output('fan:PRdes', 2.8),
    des_vars.add_output('fan:effPoly', 0.915),
    des_vars.add_output('duct21:dPqP', 0.005)
    
    des_vars.add_output('splitter:BPR', 1.0),
    des_vars.add_output('ductcore:dPqP',0.025 ),
    des_vars.add_output('ductbypassa:dPqP', 0.008),
    
    des_vars.add_output('hpc:PRdes', 14.285),
    des_vars.add_output('hpc:effPoly', 0.915),
    des_vars.add_output('duct3:dPqP', 0.005),
    des_vars.add_output('combustor:dPqP', 0.035),
    des_vars.add_output('duct40:dPqP', 0.005)
    des_vars.add_output('hpt:effPoly', 0.890),
    des_vars.add_output('hpt:PRdes', 3.0),
    des_vars.add_output('duct42:dPqP', 0.005),
    des_vars.add_output('lpt:effPoly', 0.905),
    des_vars.add_output('lpt:PRdes', 3.0)
    des_vars.add_output('duct7:dPqP', 0.005),
    
    des_vars.add_output('ductbypassb:dPqP', 0.022),
    
    #Mixer
    
    des_vars.add_output('duct8:dPqP', 0.0),
    des_vars.add_output('afterburner:dPqP', 0.0265)
    des_vars.add_output('afterburner:FAR', 0.0001)
    des_vars.add_output('nozzle:Cv', 0.978),

    des_vars.add_output('vcesplitter:BPR', 0.25)
    des_vars.add_output('duct1a:dPqP', 0.0),
    des_vars.add_output('vcefan:PR', 1.713),
    des_vars.add_output('vcefan:effDes', 0.845),
    des_vars.add_output('vcebypassa:dPqP', 0.010),
    des_vars.add_output('vcebypassb:dPqP', 0.005),
    des_vars.add_output('vceaugmentor:dPqP', 0.0265),
    des_vars.add_output('vceaugmentor:FAR', 0.0001),
    des_vars.add_output('vcenozzle:Cv', 0.985),
    
    des_vars.add_output('lp_shaft:Nmech', 3000, units='rpm'),
    des_vars.add_output('hp_shaft:Nmech', 6000, units='rpm'),
    des_vars.add_output('hp_shaft:HPX', 200., units='hp'),
    
    #
    #MN Flows
    #
    des_vars.add_output('inlet:MN_out', 0.45),
    des_vars.add_output('vcesplitter:MN_out1', 0.45),
    des_vars.add_output('duct1:MN_out', 0.45),
    des_vars.add_output('fan:MN_out', 0.3),
    des_vars.add_output('duct21:MN_out', 0.25),
    des_vars.add_output('splitter:MN_out1', 0.2),
    des_vars.add_output('ductcore:MN_out', 0.2)
    des_vars.add_output('hpc:MN_out', 0.4),
    des_vars.add_output('bleeds:MN_out', 0.15),
    des_vars.add_output('duct3:MN_out', 0.0978),
    des_vars.add_output('combustor:MN_out', 0.15),
    des_vars.add_output('duct40:MN_out', 0.1),
    des_vars.add_output('hpt:MN_out', 0.4),
    des_vars.add_output('duct42:MN_out', 0.4)
    des_vars.add_output('lpt:MN_out', 0.4),
    des_vars.add_output('duct7:MN_out', 0.2),
    
    des_vars.add_output('splitter:MN_out2', 0.4),
    des_vars.add_output('ductbypassa:MN_out', 0.2),
    des_vars.add_output('ductbypassb:MN_out', 0.2693),
    
    #Mixer
    
    des_vars.add_output('duct8:MN_out', 0.25)
    des_vars.add_output('afterburner:MN_out', 0.2573)
    
    #Central nozzle
    
    des_vars.add_output('vcesplitter:MN_out2', 0.3)
    des_vars.add_output('duct1a:MN_out', 0.3)
    des_vars.add_output('vcefan:MN_out', 0.3)    
    des_vars.add_output('vcebypassa:MN_out', 0.33)
    des_vars.add_output('vcebypassb:MN_out', 0.36)
    des_vars.add_output('vceaugmentor:MN_out', 0.3717)    
    

    #
    #
    #
    
    #
    #Cooling Flow Values
    #
    des_vars.add_output('hpc:bleed_hpc1:frac_W', 0.0001),
    des_vars.add_output('hpc:bleed_hpc1:frac_P', 0.5),
    des_vars.add_output('hpc:bleed_hpc1:frac_work', 0.2),
    
    des_vars.add_output('hpc:bleed_hpc2:frac_W', 0.0001),
    des_vars.add_output('hpc:bleed_hpc2:frac_P', 0.55),
    des_vars.add_output('hpc:bleed_hpc2:frac_work', 0.4),
    
    des_vars.add_output('hpc:bleed_hpc42:frac_W', 0.0001),
    des_vars.add_output('hpc:bleed_hpc42:frac_P', 0.5),
    des_vars.add_output('hpc:bleed_hpc42:frac_work', 0.4),
    
    des_vars.add_output('hpc:bleed_hpc49:frac_W', 0.0001),
    des_vars.add_output('hpc:bleed_hpc49:frac_P', 0.55),
    des_vars.add_output('hpc:bleed_hpc49:frac_work', 0.4),
    
    des_vars.add_output('bleeds:bleed_srce1:frac_W', 0.01),
    des_vars.add_output('bleeds:bleed_srce2:frac_W', 0.01),
    des_vars.add_output('bleeds:cust:frac_W', 0.0),
    
    des_vars.add_output('hpt:bleed_srce1:frac_P', 1.0),
    des_vars.add_output('hpt:bleed_srce2:frac_P', 0.0),
    des_vars.add_output('hpt:bleed_42:frac_P', 1.0),
    
    des_vars.add_output('lpt:bleed_lpt1:frac_P', 1.0),
    des_vars.add_output('lpt:bleed_lpt2:frac_P', 0.0),
    des_vars.add_output('lpt:bleed_49:frac_P', 1.0),
    
    #
    #
    #
    
    # OFF DESIGN
    des_vars.add_output('OD_MN', [0.2, 0.4, 0.6, 0.7, 0.8, 0.9, 1.0, 1.0, 1.2, 1.3]),    
    des_vars.add_output('OD_alt', [0.1, 1000, 5000, 10000.0, 15000.0, 20000.0, 25000.0, 30000.0, 30000., 25000.], units='ft'),
    #des_vars.add_output('OD_Fn_target', [38000, 28000, 23000, 21000], units='lbf'), #8950.0    
    des_vars.add_output('OD_dTs', [18.0, 18.0, 18.0, 18.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], units='degR')    
    des_vars.add_output('OD_AB_FAR', [0.00001, 0.00001, 0.00001, 0.00001, 0.00001, 0.00001, 0.00001, 0.01])
    des_vars.add_output('OD_vce_FAR', [0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001])
    des_vars.add_output('OD_cust_fracW', [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    
    #########################
    # DESIGN CASE
    #########################

    
    DESIGN = prob.model.add_subsystem('DESIGN', VCE5(design=True, cooling=False))

    designcooling = DESIGN.options['cooling']

    prob.model.connect('T4max', 'DESIGN.balance.rhs:FAR')
    #prob.model.connect('OPR_des', 'DESIGN.balance.rhs:hpc_PR')
    prob.model.connect('mix_ER', 'DESIGN.balance.rhs:BPR')
    
    prob.model.connect('alt', 'DESIGN.fc.alt')
    prob.model.connect('MN', 'DESIGN.fc.MN')
    prob.model.connect('dTs', 'DESIGN.fc.dTs')
                                 
    
    prob.model.connect('W', 'DESIGN.inlet.Fl_I:stat:W')
    prob.model.connect('inlet:etaBase', 'DESIGN.inlet.etaBase')
    prob.model.connect('inlet:MN_out', 'DESIGN.inlet.MN')
    
    prob.model.connect('vcesplitter:MN_out1', 'DESIGN.vcesplitter.MN1')
    prob.model.connect('vcesplitter:MN_out2', 'DESIGN.vcesplitter.MN2')
    prob.model.connect('vcesplitter:BPR', 'DESIGN.vcesplitter.BPR')
    
    prob.model.connect('duct1:dPqP', 'DESIGN.duct1.dPqP')
    prob.model.connect('duct1:MN_out', 'DESIGN.duct1.MN')
    
    prob.model.connect('fan:effPoly', 'DESIGN.balance.rhs:fan_eff')
    prob.model.connect('fan:PRdes', 'DESIGN.fan.PR')
    prob.model.connect('fan:MN_out', 'DESIGN.fan.MN')
    
    prob.model.connect('duct21:dPqP', 'DESIGN.duct21.dPqP')
    prob.model.connect('duct21:MN_out', 'DESIGN.duct21.MN')

    prob.model.connect('splitter:MN_out1', 'DESIGN.splitter.MN1')
    prob.model.connect('splitter:MN_out2', 'DESIGN.splitter.MN2')
    
    prob.model.connect('ductcore:dPqP', 'DESIGN.ductcore.dPqP')
    prob.model.connect('ductcore:MN_out', 'DESIGN.ductcore.MN')
    
    prob.model.connect('ductbypassa:dPqP', 'DESIGN.ductbypassa.dPqP')
    prob.model.connect('ductbypassa:MN_out', 'DESIGN.ductbypassa.MN')
    
    prob.model.connect('hpc:effPoly', 'DESIGN.balance.rhs:hpc_eff')
    prob.model.connect('hpc:MN_out', 'DESIGN.hpc.MN')
    prob.model.connect('hpc:PRdes', 'DESIGN.hpc.PR')
    
    prob.model.connect('duct3:dPqP', 'DESIGN.duct3.dPqP')
    prob.model.connect('duct3:MN_out', 'DESIGN.duct3.MN')

    prob.model.connect('bleeds:MN_out', 'DESIGN.bleeds.MN')

    prob.model.connect('combustor:dPqP', 'DESIGN.combustor.dPqP')
    prob.model.connect('combustor:MN_out', 'DESIGN.combustor.MN')
    
    prob.model.connect('duct40:MN_out', 'DESIGN.duct40.MN')
    prob.model.connect('duct40:dPqP', 'DESIGN.duct40.dPqP')

    prob.model.connect('hpt:effPoly', 'DESIGN.balance.rhs:hpt_eff')
    prob.model.connect('hpt:MN_out', 'DESIGN.hpt.MN')
    
    prob.model.connect('duct42:MN_out', 'DESIGN.duct42.MN')
    prob.model.connect('duct42:dPqP', 'DESIGN.duct42.dPqP')

    prob.model.connect('lpt:effPoly', 'DESIGN.balance.rhs:lpt_eff')
    prob.model.connect('lpt:MN_out', 'DESIGN.lpt.MN')
    
    prob.model.connect('duct7:dPqP', 'DESIGN.duct7.dPqP')
    prob.model.connect('duct7:MN_out', 'DESIGN.duct7.MN')
    
    prob.model.connect('ductbypassb:dPqP', 'DESIGN.ductbypassb.dPqP')
    prob.model.connect('ductbypassb:MN_out', 'DESIGN.ductbypassb.MN')
    
    prob.model.connect('duct8:dPqP', 'DESIGN.duct8.dPqP')
    prob.model.connect('duct8:MN_out', 'DESIGN.duct8.MN')
    
    prob.model.connect('afterburner:dPqP', 'DESIGN.afterburner.dPqP')
    prob.model.connect('afterburner:MN_out', 'DESIGN.afterburner.MN')
    prob.model.connect('afterburner:FAR', 'DESIGN.afterburner.Fl_I:FAR')

    prob.model.connect('nozzle:Cv', 'DESIGN.nozzle.Cv')
    
    prob.model.connect('duct1a:MN_out', 'DESIGN.duct1a.MN')
    prob.model.connect('duct1a:dPqP', 'DESIGN.duct1a.dPqP')
    
    prob.model.connect('vcefan:PR', 'DESIGN.vcefan.PR')
    prob.model.connect('vcefan:effDes', 'DESIGN.vcefan.eff')
    prob.model.connect('vcefan:MN_out', 'DESIGN.vcefan.MN')
    
    prob.model.connect('vcebypassa:dPqP', 'DESIGN.vcebypassa.dPqP')
    prob.model.connect('vcebypassa:MN_out', 'DESIGN.vcebypassa.MN')
    
    prob.model.connect('vcebypassb:dPqP', 'DESIGN.vcebypassb.dPqP')
    prob.model.connect('vcebypassb:MN_out', 'DESIGN.vcebypassb.MN')
    
    prob.model.connect('vceaugmentor:dPqP', 'DESIGN.vceaugmentor.dPqP')
    prob.model.connect('vceaugmentor:MN_out', 'DESIGN.vceaugmentor.MN')
    prob.model.connect('vceaugmentor:FAR', 'DESIGN.vceaugmentor.Fl_I:FAR')
    
    prob.model.connect('vcenozzle:Cv', 'DESIGN.vcenozzle.Cv')
        
    prob.model.connect('lp_shaft:Nmech', 'DESIGN.LP_Nmech')
    prob.model.connect('hp_shaft:Nmech', 'DESIGN.HP_Nmech')
    prob.model.connect('hp_shaft:HPX', 'DESIGN.hp_shaft.HPX')
    
    #Cooling connections
    prob.model.connect('hpc:bleed_hpc1:frac_P', 'DESIGN.hpc.bleed_hpc1:frac_P')
    prob.model.connect('hpc:bleed_hpc1:frac_work', 'DESIGN.hpc.bleed_hpc1:frac_work')
    
    prob.model.connect('hpc:bleed_hpc2:frac_P', 'DESIGN.hpc.bleed_hpc2:frac_P')
    prob.model.connect('hpc:bleed_hpc2:frac_work', 'DESIGN.hpc.bleed_hpc2:frac_work')
    
    prob.model.connect('hpt:bleed_srce1:frac_P', 'DESIGN.hpt.bleed_srce1:frac_P')
    prob.model.connect('hpt:bleed_srce2:frac_P', 'DESIGN.hpt.bleed_srce2:frac_P')
    prob.model.connect('hpt:bleed_42:frac_P', 'DESIGN.hpt.bleed_42:frac_P')
    
    prob.model.connect('lpt:bleed_lpt1:frac_P', 'DESIGN.lpt.bleed_lpt1:frac_P')
    prob.model.connect('lpt:bleed_lpt2:frac_P', 'DESIGN.lpt.bleed_lpt2:frac_P')
    prob.model.connect('lpt:bleed_49:frac_P', 'DESIGN.lpt.bleed_49:frac_P')

    if not designcooling:
        prob.model.connect('hpc:bleed_hpc1:frac_W', 'DESIGN.hpc.bleed_hpc1:frac_W')
        prob.model.connect('hpc:bleed_hpc2:frac_W', 'DESIGN.hpc.bleed_hpc2:frac_W')
        prob.model.connect('bleeds:bleed_srce1:frac_W', 'DESIGN.bleeds.bleed_srce1:frac_W')
        prob.model.connect('bleeds:bleed_srce2:frac_W', 'DESIGN.bleeds.bleed_srce2:frac_W')
        
    # OFF DESIGN CASES
    pts = []
    #pts = ['OD1']#,'OD2','OD3','OD4', 'OD5', 'OD6', 'OD7', 'OD8']#, 'OD9', 'OD10']

    for i_OD, pt in enumerate(pts):
        ODpt = prob.model.add_subsystem(pt, VCE5(design=False, cooling=False))
        
        ODcooling = ODpt.options['cooling']
        
        prob.model.connect('OD_alt', pt+'.fc.alt', src_indices=i_OD)
        prob.model.connect('OD_MN', pt+'.fc.MN', src_indices=i_OD)
        prob.model.connect('OD_dTs', pt+'.fc.dTs', src_indices=i_OD)
        prob.model.connect('OD_cust_fracW', pt+'.bleeds.cust:frac_W', src_indices=i_OD)
        prob.model.connect('T4max', pt+'.balance.rhs:FAR')
        #prob.model.connect('ABTmax', pt+'.balance.rhs:FAR_AB')
        #prob.model.connect('DESIGN.fan.map.RlineMap', pt+'.balance.rhs:W')
        prob.model.connect('mix_ER', pt+'.balance.rhs:BPR')
        prob.model.connect('OD_AB_FAR', pt+'.afterburner.Fl_I:FAR', src_indices=i_OD)
        prob.model.connect('OD_vce_FAR', pt+'.vceaugmentor.Fl_I:FAR', src_indices=i_OD)
        prob.model.connect('DESIGN.vcenozzle.Throat:stat:area', pt+'.balance.rhs:vce_BPR')
        
        prob.model.connect('inlet:etaBase', pt+'.inlet.etaBase')
        prob.model.connect('nozzle:Cv', pt+'.nozzle.Cv')
        prob.model.connect('vcenozzle:Cv', pt+'.vcenozzle.Cv')
        prob.model.connect('hp_shaft:HPX', pt+'.hp_shaft.HPX')
        prob.model.connect('DESIGN.duct1.s_dPqP', pt+'.duct1.s_dPqP')
        prob.model.connect('DESIGN.duct21.s_dPqP', pt+'.duct21.s_dPqP')
        prob.model.connect('DESIGN.ductcore.s_dPqP', pt+'.ductcore.s_dPqP')
        prob.model.connect('DESIGN.ductbypassa.s_dPqP', pt+'.ductbypassa.s_dPqP')
        prob.model.connect('DESIGN.duct3.s_dPqP', pt+'.duct3.s_dPqP')
        prob.model.connect('combustor:dPqP', pt+'.combustor.dPqP')        
        prob.model.connect('DESIGN.duct40.s_dPqP', pt+'.duct40.s_dPqP')
        prob.model.connect('DESIGN.duct42.s_dPqP', pt+'.duct42.s_dPqP')
        prob.model.connect('DESIGN.duct7.s_dPqP', pt+'.duct7.s_dPqP')
        prob.model.connect('ductbypassb:dPqP', pt+'.ductbypassb.dPqP')
        prob.model.connect('DESIGN.duct8.s_dPqP', pt+'.duct8.s_dPqP')
        prob.model.connect('afterburner:dPqP', pt+'.afterburner.dPqP')
        prob.model.connect('DESIGN.duct1a.s_dPqP', pt+'.duct1a.s_dPqP')
        prob.model.connect('DESIGN.vcebypassa.s_dPqP', pt+'.vcebypassa.s_dPqP')
        prob.model.connect('DESIGN.vcebypassb.s_dPqP', pt+'.vcebypassb.s_dPqP')
        prob.model.connect('vceaugmentor:dPqP', pt+'.vceaugmentor.dPqP')

        prob.model.connect('DESIGN.fan.s_PR', pt+'.fan.s_PR')
        prob.model.connect('DESIGN.fan.s_Wc', pt+'.fan.s_Wc')
        prob.model.connect('DESIGN.fan.s_eff', pt+'.fan.s_eff')
        prob.model.connect('DESIGN.fan.s_Nc', pt+'.fan.s_Nc')
        
        prob.model.connect('DESIGN.vcefan.s_PR', pt+'.vcefan.s_PR')
        prob.model.connect('DESIGN.vcefan.s_Wc', pt+'.vcefan.s_Wc')
        prob.model.connect('DESIGN.vcefan.s_eff', pt+'.vcefan.s_eff')
        prob.model.connect('DESIGN.vcefan.s_Nc', pt+'.vcefan.s_Nc')
        
        prob.model.connect('DESIGN.hpc.s_PR', pt+'.hpc.s_PR')
        prob.model.connect('DESIGN.hpc.s_Wc', pt+'.hpc.s_Wc')
        prob.model.connect('DESIGN.hpc.s_eff', pt+'.hpc.s_eff')
        prob.model.connect('DESIGN.hpc.s_Nc', pt+'.hpc.s_Nc')
        
        prob.model.connect('DESIGN.hpt.s_PR', pt+'.hpt.s_PR')
        prob.model.connect('DESIGN.hpt.s_Wp', pt+'.hpt.s_Wp')
        prob.model.connect('DESIGN.hpt.s_eff', pt+'.hpt.s_eff')
        prob.model.connect('DESIGN.hpt.s_Np', pt+'.hpt.s_Np')
        
        prob.model.connect('DESIGN.lpt.s_PR', pt+'.lpt.s_PR')
        prob.model.connect('DESIGN.lpt.s_Wp', pt+'.lpt.s_Wp')
        prob.model.connect('DESIGN.lpt.s_eff', pt+'.lpt.s_eff')
        prob.model.connect('DESIGN.lpt.s_Np', pt+'.lpt.s_Np')
        
        #
        # AREA CONNECTIONS
        #
        prob.model.connect('DESIGN.inlet.Fl_O:stat:area', pt+'.inlet.area')
        prob.model.connect('DESIGN.vcesplitter.Fl_O1:stat:area', pt+'.vcesplitter.area1')
        prob.model.connect('DESIGN.vcesplitter.Fl_O2:stat:area', pt+'.vcesplitter.area2')
        prob.model.connect('DESIGN.duct1.Fl_O:stat:area', pt+'.duct1.area')
        prob.model.connect('DESIGN.fan.Fl_O:stat:area', pt+'.fan.area')
        prob.model.connect('DESIGN.duct21.Fl_O:stat:area', pt+'.duct21.area')
        prob.model.connect('DESIGN.splitter.Fl_O1:stat:area', pt+'.splitter.area1')
        prob.model.connect('DESIGN.splitter.Fl_O2:stat:area', pt+'.splitter.area2')
        prob.model.connect('DESIGN.ductcore.Fl_O:stat:area', pt+'.ductcore.area')
        prob.model.connect('DESIGN.ductbypassa.Fl_O:stat:area', pt+'.ductbypassa.area')
        prob.model.connect('DESIGN.hpc.Fl_O:stat:area', pt+'.hpc.area')
        prob.model.connect('DESIGN.duct3.Fl_O:stat:area', pt+'.duct3.area')
        prob.model.connect('DESIGN.bleeds.Fl_O:stat:area', pt+'.bleeds.area')
        prob.model.connect('DESIGN.combustor.Fl_O:stat:area', pt+'.combustor.area')
        prob.model.connect('DESIGN.duct40.Fl_O:stat:area', pt+'.duct40.area')
        prob.model.connect('DESIGN.hpt.Fl_O:stat:area', pt+'.hpt.area')
        prob.model.connect('DESIGN.duct42.Fl_O:stat:area', pt+'.duct42.area')
        prob.model.connect('DESIGN.lpt.Fl_O:stat:area', pt+'.lpt.area')
        prob.model.connect('DESIGN.duct7.Fl_O:stat:area', pt+'.duct7.area')
        prob.model.connect('DESIGN.ductbypassb.Fl_O:stat:area', pt+'.ductbypassb.area')
        prob.model.connect('DESIGN.mixer.Fl_O:stat:area', pt+'.mixer.area')
        prob.model.connect('DESIGN.mixer.Fl_I1_calc:stat:area', pt+'.mixer.Fl_I1_stat_calc.area')
        prob.model.connect('DESIGN.duct8.Fl_O:stat:area', pt+'.duct8.area')
        prob.model.connect('DESIGN.afterburner.Fl_O:stat:area', pt+'.afterburner.area')
        prob.model.connect('DESIGN.duct1a.Fl_O:stat:area', pt+'.duct1a.area')
        prob.model.connect('DESIGN.vcebypassa.Fl_O:stat:area', pt+'.vcebypassa.area')
        prob.model.connect('DESIGN.vcebypassb.Fl_O:stat:area', pt+'.vcebypassb.area')
        prob.model.connect('DESIGN.vceaugmentor.Fl_O:stat:area', pt+'.vceaugmentor.area')

        #OD Cooling
        prob.model.connect('hpc:bleed_hpc1:frac_P', pt+'.hpc.bleed_hpc1:frac_P')
        prob.model.connect('hpc:bleed_hpc1:frac_work', pt+'.hpc.bleed_hpc1:frac_work')
    
        prob.model.connect('hpc:bleed_hpc2:frac_P', pt+'.hpc.bleed_hpc2:frac_P')
        prob.model.connect('hpc:bleed_hpc2:frac_work', pt+'.hpc.bleed_hpc2:frac_work')
    
        prob.model.connect('hpt:bleed_srce1:frac_P', pt+'.hpt.bleed_srce1:frac_P')
        prob.model.connect('hpt:bleed_srce2:frac_P', pt+'.hpt.bleed_srce2:frac_P')
        prob.model.connect('hpt:bleed_42:frac_P', pt+'.hpt.bleed_42:frac_P')
    
        prob.model.connect('lpt:bleed_lpt1:frac_P', pt+'.lpt.bleed_lpt1:frac_P')
        prob.model.connect('lpt:bleed_lpt2:frac_P', pt+'.lpt.bleed_lpt2:frac_P')
        prob.model.connect('lpt:bleed_49:frac_P', pt+'.lpt.bleed_49:frac_P')
        
        if not ODcooling:
            if designcooling:            
                prob.model.connect('DESIGN.balance.lpt_nochrg_cool_frac', pt+'.hpc.bleed_hpc1:frac_W')
                prob.model.connect('DESIGN.balance.lpt_chrg_cool_frac', pt+'.hpc.bleed_hpc2:frac_W')
                prob.model.connect('DESIGN.balance.hpt_nochrg_cool_frac', pt+'.bleeds.bleed_srce1:frac_W')
                prob.model.connect('DESIGN.balance.hpt_chrg_cool_frac', pt+'.bleeds.bleed_srce2:frac_W')
            
            if not designcooling:
                prob.model.connect('hpc:bleed_hpc1:frac_W', pt+'.hpc.bleed_hpc1:frac_W')
                prob.model.connect('hpc:bleed_hpc2:frac_W', pt+'.hpc.bleed_hpc2:frac_W')
                prob.model.connect('bleeds:bleed_srce1:frac_W', pt+'.bleeds.bleed_srce1:frac_W')
                prob.model.connect('bleeds:bleed_srce2:frac_W', pt+'.bleeds.bleed_srce2:frac_W')
            

    prob.setup(check=False)

    # initial guesses
    prob['DESIGN.balance.FAR'] = 0.032
    #prob['DESIGN.balance.FAR_AB'] = 0.032
    #prob['DESIGN.balance.W'] = 215
    prob['DESIGN.balance.fan_eff'] = 0.89
    prob['DESIGN.balance.hpc_eff'] = 0.87
    prob['DESIGN.balance.lpt_eff'] = 0.90
    prob['DESIGN.balance.hpt_eff'] = 0.90
    prob['DESIGN.balance.BPR'] = 2.1
    #prob['DESIGN.balance.core_MN'] = .9
    #prob['DESIGN.balance.fan_PR'] = 7
    prob['DESIGN.balance.hpt_PR'] = 4.0
    prob['DESIGN.balance.lpt_PR'] = 3.4
    prob['DESIGN.fc.balance.Pt'] = 5.2
    prob['DESIGN.fc.balance.Tt'] = 440.0
    prob['DESIGN.mixer.balance.P_tot']= 40
    
    FAR_guesses = [.034, .034, .034, .034, .034, .034, .034, .034, .034, .034]
    #FAB_AB_guesses = [.035, .035, .035, .035, .035, .035, .035, .035, .035, .035]
    W_guesses = [570, 550, 550, 550, 550, 450, 400, 400, 220, 220]
    #lp_Nmech_guesses = [4600, 4600, 4600, 4700, 4700, 4700, 4700, 4700, 4700, 4500]
    #hp_Nmech_guesses = [14700, 14700, 14800, 14700, 14700, 14700, 14700, 14700, 14700, 14700]    
    
    for i, pt in enumerate(pts):
        # ADP and TOC guesses
        prob[pt+'.balance.FAR'] = FAR_guesses[i]
        prob[pt+'.balance.W'] = W_guesses[i]
        #prob[pt+'.balance.FAR_AB'] = FAB_AB_guesses[i]
        prob[pt+'.balance.BPR'] = 2.2
        prob[pt+'.balance.vce_BPR'] = 0.25
        prob[pt+'.balance.lp_Nmech'] = 3000
        prob[pt+'.balance.hp_Nmech'] = 6000
        prob[pt+'.mixer.balance.P_tot'] = 40
        prob[pt+'.fc.balance.Pt'] = 14
        prob[pt+'.fc.balance.Tt'] = 540
        prob[pt+'.hpt.PR'] = 4.0
        prob[pt+'.lpt.PR'] = 3.3
        prob[pt+'.fan.map.RlineMap'] = 2.2
        prob[pt+'.vcefan.map.RlineMap'] = 2.2
        prob[pt+'.hpc.map.RlineMap'] = 2.05

    st = time.time()

    prob.set_solver_print(level=-1)
    prob.set_solver_print(level=2, depth=1)
    prob.run_model()
    prob.model.DESIGN.list_outputs(residuals=True, residuals_tol=1e-2)


    for pt in ['DESIGN']+pts:
        viewer(prob, pt)


    print()
    print("time", time.time() - st)

