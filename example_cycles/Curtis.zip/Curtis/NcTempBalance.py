import numpy as np

from openmdao.api import ImplicitComponent

class FARBalance(ImplicitComponent):

    def setup(self):
        
        self.add_input('T4', val=3500, units='degR')
        
        self.add_input('T4max', val=3660, units='degR')
        
        self.add_input('NcMapVal', val=0.98)
        
        self.add_input('NcMapTgt', val=1.0)
        
        self.add_output('FAR', val=.034)
        
        self.declare_partials('FAR', ['NcMapVal', 'T4'], method = 'fd')
        
    def apply_nonlinear(self, inputs, outputs, residuals):
        
        T4 = inputs['T4']
        T4max = inputs['T4max']
        
        NcMapVal = inputs['NcMapVal']
        NcMapTgt = inputs['NcMapTgt']
        
        if T4 >= T4max:
            residuals['FAR'] = T4 - T4max
            
        else:
            residuals['FAR'] = NcMapVal - NcMapTgt
            
