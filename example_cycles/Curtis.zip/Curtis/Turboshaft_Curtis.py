import sys

import openmdao.api as om

import pycycle.api as pyc

class TurboshaftPractice(om.Group):
    
    def initialize(self):
        self.options.declare('design', default = True, 
                             desc = 'switch between on-design and off-design calculations')
        
    def setup(self):
        
        thermo_spec = pyc.species_data.janaf
        design = self.options['design']

        #engine elements
        self.add_subsystem('fc', pyc.FlightConditions(thermo_data=thermo_spec, 
                                      elements=pyc.AIR_MIX))
        self.add_subsystem('inlet', pyc.Inlet(design=design, thermo_data=thermo_spec,
                                      elements=pyc.AIR_MIX))
        self.add_subsystem('hpc', pyc.Compressor(map_data=pyc.AXI5, design=design,
                                    thermo_data=thermo_spec, elements=pyc.AIR_MIX, map_extrap=True, bleed_names=['cool']),
                                    promotes_inputs=[('Nmech', 'HP_Nmech')])
        self.add_subsystem('burner', pyc.Combustor(design=design,thermo_data=thermo_spec,
                                    inflow_elements=pyc.AIR_MIX,
                                    air_fuel_elements=pyc.AIR_FUEL_MIX,
                                    fuel_type='JP-7'))
        self.add_subsystem('hpt', pyc.Turbine(map_data=pyc.LPT2269, design=design,
                                    thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX, map_extrap=True, bleed_names=['cool']),
                                    promotes_inputs=[('Nmech', 'HP_Nmech')])
        self.add_subsystem('lpt', pyc.Turbine(map_data=pyc.LPT2269, design=design,
                                    thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX, map_extrap=True),
                                    promotes_inputs=[('Nmech', 'LP_Nmech')])
        self.add_subsystem('nozzle', pyc.Nozzle(nozzType = 'CV', lossCoef='Cv', 
                                    thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))
        self.add_subsystem('hp_shaft', pyc.Shaft(num_ports=2), promotes_inputs=[('Nmech', 'HP_Nmech')])
        self.add_subsystem('lp_shaft', pyc.Shaft(num_ports=1), promotes_inputs=[('Nmech', 'LP_Nmech')])
        self.add_subsystem('perf', pyc.Performance(num_nozzles=1, num_burners=1))


        #Connect flow stations
        pyc.connect_flow(self, 'fc.Fl_O', 'inlet.Fl_I', connect_w=False)
        pyc.connect_flow(self, 'inlet.Fl_O', 'hpc.Fl_I')
        pyc.connect_flow(self, 'hpc.Fl_O', 'burner.Fl_I')
        pyc.connect_flow(self, 'burner.Fl_O', 'hpt.Fl_I')
        pyc.connect_flow(self, 'hpt.Fl_O', 'lpt.Fl_I')
        pyc.connect_flow(self, 'lpt.Fl_O', 'nozzle.Fl_I')
        
        #connect turbomachinery components to shaft
        self.connect('hpc.trq', 'hp_shaft.trq_0')
        self.connect('hpt.trq', 'hp_shaft.trq_1')
        self.connect('lpt.trq', 'lp_shaft.trq_0')
        
        #connect nozzle exhause to freestream static conditions
        self.connect('fc.Fl_O:stat:P', 'nozzle.Ps_exhaust')
        
        #Connect outputs to performance element
        self.connect('inlet.Fl_O:tot:P', 'perf.Pt2')
        self.connect('hpc.Fl_O:tot:P', 'perf.Pt3')
        self.connect('burner.Wfuel', 'perf.Wfuel_0')
        self.connect('inlet.F_ram', 'perf.ram_drag')
        self.connect('nozzle.Fg', 'perf.Fg_0')
        self.connect('lp_shaft.pwr_net', 'perf.power')
        
        pyc.connect_flow(self, 'hpc.cool', 'hpt.cool', connect_stat=False)
        
        #Add balances for design and off-design
        balance = self.add_subsystem('balance', om.BalanceComp())
        if design:
            
            balance.add_balance('W', val=27, units='lbm/s', eq_units=None)
            self.connect('balance.W', 'inlet.Fl_I:stat:W')
            self.connect('nozzle.PR', 'balance.lhs:W')
            
            balance.add_balance('FAR', eq_units='degR', lower=1e-4, val=.017)
            self.connect('balance.FAR', 'burner.Fl_I:FAR')
            self.connect('burner.Fl_O:tot:T', 'balance.lhs:FAR')
            
            balance.add_balance('hpt_PR', val=3.0, lower=1.001, upper=8, eq_units='hp', rhs_val=0.)
            self.connect('balance.hpt_PR', 'hpt.PR')
            self.connect('hp_shaft.pwr_net', 'balance.lhs:hpt_PR')
            
            balance.add_balance('lpt_PR', val=3.0, lower=1.001, upper=8, eq_units='hp')
            self.connect('balance.lpt_PR', 'lpt.PR')
            self.connect('lp_shaft.pwr_net', 'balance.lhs:lpt_PR')
            
        else:
            
            balance.add_balance('FAR', eq_units='hp', lower=1e-4, val=.3)
            self.connect('balance.FAR', 'burner.Fl_I:FAR')
            self.connect('lp_shaft.pwr_net', 'balance.lhs:FAR')
            
            balance.add_balance('HP_Nmech', val=8000, units='rpm', lower=500, eq_units='hp', rhs_val=0.)
            self.connect('balance.HP_Nmech', 'HP_Nmech')
            self.connect('hp_shaft.pwr_net', 'balance.lhs:HP_Nmech')            
            
            balance.add_balance('W', val=27.0, units='lbm/s', eq_units='inch**2')
            self.connect('balance.W', 'inlet.Fl_I:stat:W')
            self.connect('nozzle.Throat:stat:area', 'balance.lhs:W')
            
        #Setup solver to converge engine
        self.set_order(['balance', 'fc', 'inlet', 'hpc', 'burner', 'hpt', 'lpt', 'nozzle', 'hp_shaft', 'lp_shaft', 'perf'])
        
        newton = self.nonlinear_solver = om.NewtonSolver()
        newton.options['atol'] = 1e-6
        newton.options['rtol'] = 1e-6
        newton.options['iprint'] = 2
        newton.options['maxiter'] = 15
        newton.options['solve_subsystems'] = True
        newton.options['max_sub_solves'] = 100
        newton.options['reraise_child_analysiserror'] = False

        # newton.linesearch = om.BoundsEnforceLS()
        newton.linesearch = om.ArmijoGoldsteinLS()
        # newton.linesearch.options['c'] = .0001
        newton.linesearch.options['bound_enforcement'] = 'scalar'
        newton.linesearch.options['iprint'] = -1       
        
        self.linear_solver = om.DirectSolver(assemble_jac=True)
        
def viewer(prob, pt, file=sys.stdout):
    """
    print a report of all the relevant cycle properties
    """

    print(file=file, flush=True)
    print(file=file, flush=True)
    print(file=file, flush=True)
    print("----------------------------------------------------------------------------", file=file, flush=True)
    print("                              POINT:", pt, file=file, flush=True)
    print("----------------------------------------------------------------------------", file=file, flush=True)
    print("                       PERFORMANCE CHARACTERISTICS", file=file, flush=True)
    print("    Mach      Alt       W      Fn      Fg    Fram     OPR     PSFC", file=file, flush=True)
    print(" %7.5f  %7.1f %7.3f %7.1f %7.1f %7.1f %7.3f  %7.5f " \
              %(prob[pt+'.fc.Fl_O:stat:MN'], prob[pt+'.fc.alt'],prob[pt+'.inlet.Fl_O:stat:W'], \
                prob[pt+'.perf.Fn'],prob[pt+'.perf.Fg'],prob[pt+'.inlet.F_ram'],prob[pt+'.perf.OPR'], \
                prob[pt+'.perf.PSFC']), file=file, flush=True)


    fs_names = ['fc.Fl_O', 'inlet.Fl_O', 'hpc.Fl_O', 'burner.Fl_O',
                'hpt.Fl_O', 'lpt.Fl_O', 'nozzle.Fl_O']
    
    fs_full_names = [f'{pt}.{fs}' for fs in fs_names]
    pyc.print_flow_station(prob, fs_full_names, file=file)

    comp_names = ['hpc']
    comp_full_names = [f'{pt}.{c}' for c in comp_names]
    pyc.print_compressor(prob, comp_full_names, file=file)

    pyc.print_burner(prob, [f'{pt}.burner'])

    turb_names = ['hpt', 'lpt']
    turb_full_names = [f'{pt}.{t}' for t in turb_names]
    pyc.print_turbine(prob, turb_full_names, file=file)

    noz_names = ['nozzle']
    noz_full_names = [f'{pt}.{n}' for n in noz_names]
    pyc.print_nozzle(prob, noz_full_names, file=file)

    shaft_names = ['hp_shaft', 'lp_shaft']
    shaft_full_names = [f'{pt}.{s}' for s in shaft_names]
    pyc.print_shaft(prob, shaft_full_names, file=file)

    bleed_names = ['hpc']
    bleed_full_names = [f'{pt}.{b}' for b in bleed_names]
    pyc.print_bleed(prob, bleed_full_names, file=file)
        
        
if __name__ == "__main__":

    import time
    from openmdao.api import Problem, IndepVarComp
    from openmdao.utils.units import convert_units as cu
    
    prob = om.Problem()

    des_vars = prob.model.add_subsystem('des_vars',
                                        om.IndepVarComp(), promotes=["*"])

    # FOR DESIGN
    des_vars.add_output('alt', 0.0, units='ft'),
    des_vars.add_output('MN', 0.000001),
    des_vars.add_output('T4max', 2500.0, units='degR'),
    des_vars.add_output('pwr_des', 4000.0, units='hp'),
    des_vars.add_output('nozzle:PRdes', 1.2),
    
    des_vars.add_output('hpc:PRdes', 13.5),
    des_vars.add_output('hpc:effDes', 0.83),
    des_vars.add_output('burner:dPqP', 0.03),
    des_vars.add_output('hpt:effDes', 0.86),
    des_vars.add_output('lpt:effDes', 0.9),
    des_vars.add_output('nozzle:Cv', 0.99),
    des_vars.add_output('lp_shaft:Nmech', 5000.0, units='rpm'),
    des_vars.add_output('hp_shaft:Nmech', 8070.0, units='rpm'),
    
    des_vars.add_output('inlet:MN_out', 0.60),
    des_vars.add_output('hpc:MN_out', 0.20),
    des_vars.add_output('burner:MN_out', 0.20),
    des_vars.add_output('hpt:MN_out', 0.40),
    des_vars.add_output('lpt:MN_out', 0.50),

    des_vars.add_output('hpc:cool:frac_W', 0.05),
    des_vars.add_output('hpc:cool:frac_P', 0.5),
    des_vars.add_output('hpc:cool:frac_work', 0.5),
    des_vars.add_output('hpt:cool:frac_P', 1.0),
    
    # Off-design (point 1) inputs
    des_vars.add_output('OD1_MN', 0.1),
    des_vars.add_output('OD1_alt', 0.0, units='ft'),
    des_vars.add_output('4000', 3500.0, units='hp'),
    des_vars.add_output('OD1_LP_Nmech', 5000., units='rpm')

    # Off-design (point 1) inputs
    des_vars.add_output('OD2_MN', 0.1),
    des_vars.add_output('OD2_alt', 1000, units='ft'),
    des_vars.add_output('OD2_pwr', 3500.0, units='hp'),
    des_vars.add_output('OD2_LP_Nmech', 5000., units='rpm')
    
    # Off-design (point 2) inputs
    des_vars.add_output('OD3_MN', 0.1),
    des_vars.add_output('OD3_alt', 1000, units='ft'),
    des_vars.add_output('OD3_pwr', 3500.0, units='hp'),
    des_vars.add_output('OD3_LP_Nmech', 5000., units='rpm')
    
    # DESIGN CASE
    prob.model.add_subsystem('DESIGN', TurboshaftPractice())

    prob.model.connect('alt', 'DESIGN.fc.alt')
    prob.model.connect('MN', 'DESIGN.fc.MN')
    prob.model.connect('T4max', 'DESIGN.balance.rhs:FAR')
    prob.model.connect('pwr_des', 'DESIGN.balance.rhs:lpt_PR')
    prob.model.connect('nozzle:PRdes', 'DESIGN.balance.rhs:W')
    
    prob.model.connect('hpc:PRdes', 'DESIGN.hpc.PR')
    prob.model.connect('hpc:effDes', 'DESIGN.hpc.eff')
    prob.model.connect('burner:dPqP', 'DESIGN.burner.dPqP')
    prob.model.connect('hpt:effDes', 'DESIGN.hpt.eff')
    prob.model.connect('lpt:effDes', 'DESIGN.lpt.eff')
    #prob.model.connect('lpt:MN_out', 'DESIGN.lpt.MN')
    prob.model.connect('nozzle:Cv', 'DESIGN.nozzle.Cv')
    prob.model.connect('lp_shaft:Nmech', 'DESIGN.LP_Nmech')
    prob.model.connect('hp_shaft:Nmech', 'DESIGN.HP_Nmech')
    
    prob.model.connect('inlet:MN_out', 'DESIGN.inlet.MN')
    prob.model.connect('hpc:MN_out', 'DESIGN.hpc.MN')
    prob.model.connect('burner:MN_out', 'DESIGN.burner.MN')
    prob.model.connect('hpt:MN_out', 'DESIGN.hpt.MN')
    
    prob.model.connect('hpc:cool:frac_W', 'DESIGN.hpc.cool:frac_W')
    prob.model.connect('hpc:cool:frac_P', 'DESIGN.hpc.cool:frac_P')
    prob.model.connect('hpc:cool:frac_work', 'DESIGN.hpc.cool:frac_work')
    prob.model.connect('hpt:cool:frac_P', 'DESIGN.hpt.cool:frac_P')
    
    
    #Connect off-design and required design inputs to model
    pts = ['OD1', 'OD2', 'OD3']
     
    for pt in pts:
        
        prob.model.add_subsystem(pt, TurboshaftPractice(design=False))
        
        prob.model.connect('burner:dPqP', pt+'.burner.dPqP')
        prob.model.connect('nozzle:Cv', pt+'.nozzle.Cv')

        prob.model.connect(pt+'_alt', pt+'.fc.alt')
        prob.model.connect(pt+'_MN', pt+'.fc.MN')
        prob.model.connect(pt+'_LP_Nmech', pt+'.LP_Nmech')
        prob.model.connect(pt+'_pwr', pt+'.balance.rhs:FAR')

        prob.model.connect('DESIGN.hpc.s_PR', pt+'.hpc.s_PR')
        prob.model.connect('DESIGN.hpc.s_Wc', pt+'.hpc.s_Wc')
        prob.model.connect('DESIGN.hpc.s_eff', pt+'.hpc.s_eff')
        prob.model.connect('DESIGN.hpc.s_Nc', pt+'.hpc.s_Nc')

        prob.model.connect('DESIGN.hpt.s_PR', pt+'.hpt.s_PR')
        prob.model.connect('DESIGN.hpt.s_Wp', pt+'.hpt.s_Wp')
        prob.model.connect('DESIGN.hpt.s_eff', pt+'.hpt.s_eff')
        prob.model.connect('DESIGN.hpt.s_Np', pt+'.hpt.s_Np')

        prob.model.connect('DESIGN.lpt.s_PR', pt+'.lpt.s_PR')
        prob.model.connect('DESIGN.lpt.s_Wp', pt+'.lpt.s_Wp')
        prob.model.connect('DESIGN.lpt.s_eff', pt+'.lpt.s_eff')
        prob.model.connect('DESIGN.lpt.s_Np', pt+'.lpt.s_Np')

        prob.model.connect('DESIGN.inlet.Fl_O:stat:area', pt+'.inlet.area')
        #prob.model.connect('DESIGN.lpc.Fl_O:stat:area', pt+'.lpc.area')
        prob.model.connect('DESIGN.hpc.Fl_O:stat:area', pt+'.hpc.area')
        prob.model.connect('DESIGN.burner.Fl_O:stat:area', pt+'.burner.area')
        prob.model.connect('DESIGN.hpt.Fl_O:stat:area', pt+'.hpt.area')
        prob.model.connect('DESIGN.lpt.Fl_O:stat:area', pt+'.lpt.area')

        prob.model.connect('DESIGN:hpc:cool:frac_W', pt+'.hpc.cool:frac_W')
        prob.model.connect('DESIGN:hpc:cool:frac_P', pt+'.hpc.cool:frac_P')
        prob.model.connect('DESIGN:hpc:cool:frac_work', pt+'.hpc.cool:frac_work')
        prob.model.connect('DESIGN:hpc:cool:frac_P', pt+'.hpt.cool:frac_P')

        # prob.model.connect(pt+'_T4', pt+'.balance.rhs:FAR')
        # prob.model.connect(pt+'_pwr', pt+'.balance.rhs:FAR')
        prob.model.connect('DESIGN.nozzle.Throat:stat:area', pt+'.balance.rhs:W')

    prob.setup(check=True)

    # initial guesses
    prob['DESIGN.balance.FAR'] = 0.0175506829934
    prob['DESIGN.balance.W'] = 27.265
    prob['DESIGN.balance.hpt_PR'] = 3.0
    prob['DESIGN.balance.lpt_PR'] = 2.8148

    
    for pt in pts:
        prob[pt+'.balance.W'] = 27.265
        prob[pt+'.balance.FAR'] = 0.0175506829934
        #prob[pt+'.balance.HP_Nmech'] = 8070.0
        prob[pt+'.hpt.PR'] = 3.8768
        prob[pt+'.lpt.PR'] = 2.8148
    
    st = time.time()

    prob.set_solver_print(level=-1)
    prob.set_solver_print(level=2, depth=1)
    prob.run_model()
    
    for pt in ['DESIGN']+pts:
        viewer(prob, pt)

    print()
    print("time", time.time() - st)
