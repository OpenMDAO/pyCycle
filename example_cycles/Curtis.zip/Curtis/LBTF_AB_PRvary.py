import sys

import numpy as np

import openmdao.api as om

import pycycle.api as pyc


class LBTF_AB(om.Group):

    def initialize(self):
        self.options.declare('design', default=True,
                              desc='Switch between on-design and off-design calculation.')
        self.options.declare('cooling', default=True, 
                             desc='If True, calculate cooling flows')
        
    def setup(self):

        thermo_spec = pyc.species_data.janaf
        design = self.options['design']
        cooling = self.options['cooling']
        
        self.add_subsystem('fc', pyc.FlightConditions(thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('inlet', pyc.Inlet(design=design, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('fan', pyc.Compressor(map_data=pyc.FanMap, design=design, thermo_data=thermo_spec, elements=pyc.AIR_MIX,
                                        bleed_names=[], map_extrap=True), promotes_inputs=[('Nmech','LP_Nmech')])
        self.add_subsystem('splitter', pyc.Splitter(design=design, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        self.add_subsystem('hpc', pyc.Compressor(map_data=pyc.HPCMap, design=design, thermo_data=thermo_spec, elements=pyc.AIR_MIX,
                                        bleed_names=['cool1','cool2','cust'], map_extrap=True),promotes_inputs=[('Nmech','HP_Nmech')])
        self.add_subsystem('bld3', pyc.BleedOut(design=design, bleed_names=['cool3','cool4']))
        self.add_subsystem('burner', pyc.Combustor(design=design,thermo_data=thermo_spec,
                                        inflow_elements=pyc.AIR_MIX,
                                        air_fuel_elements=pyc.AIR_FUEL_MIX,
                                        fuel_type='JP-7'))
        self.add_subsystem('duct4', pyc.Duct(design=design, thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))
        self.add_subsystem('hpt', pyc.Turbine(map_data=pyc.HPTMap, design=design, thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX,
                                        bleed_names=['cool3','cool4'], map_extrap=True),promotes_inputs=[('Nmech','HP_Nmech')])
        self.add_subsystem('duct45', pyc.Duct(design=design, thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))
        self.add_subsystem('lpt', pyc.Turbine(map_data=pyc.LPTMap, design=design, thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX,
                                        bleed_names=['cool1','cool2'], map_extrap=True),promotes_inputs=[('Nmech','LP_Nmech')])
        self.add_subsystem('core_duct', pyc.Duct(design=design, thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))
        self.add_subsystem('byp_duct', pyc.Duct(design=design, thermo_data=thermo_spec, elements=pyc.AIR_MIX))
        
        self.add_subsystem('mixer', pyc.Mixer(design=design, thermo_data=thermo_spec, designed_stream=1, 
                                          Fl_I1_elements=pyc.AIR_FUEL_MIX, Fl_I2_elements=pyc.AIR_MIX))
        self.add_subsystem('aug_duct', pyc.Duct(design=design, thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))
        self.add_subsystem('afterburner', pyc.Combustor(design=design, thermo_data=thermo_spec,inflow_elements=pyc.AIR_FUEL_MIX,
                                            air_fuel_elements=pyc.AIR_FUEL_MIX, fuel_type='JP-7'))
        self.add_subsystem('nozz', pyc.Nozzle(nozzType='CD', lossCoef='Cfg', thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))

        self.add_subsystem('lp_shaft', pyc.Shaft(num_ports=2),promotes_inputs=[('Nmech','LP_Nmech')])
        self.add_subsystem('hp_shaft', pyc.Shaft(num_ports=2),promotes_inputs=[('Nmech','HP_Nmech')])
        self.add_subsystem('perf', pyc.Performance(num_nozzles=1, num_burners=2))

        self.connect('inlet.Fl_O:tot:P', 'perf.Pt2')
        self.connect('hpc.Fl_O:tot:P', 'perf.Pt3')
        self.connect('burner.Wfuel', 'perf.Wfuel_0')
        self.connect('afterburner.Wfuel', 'perf.Wfuel_1')
        self.connect('inlet.F_ram', 'perf.ram_drag')
        self.connect('nozz.Fg', 'perf.Fg_0')

        self.connect('fan.trq', 'lp_shaft.trq_0')
        self.connect('lpt.trq', 'lp_shaft.trq_1')
        self.connect('hpc.trq', 'hp_shaft.trq_0')
        self.connect('hpt.trq', 'hp_shaft.trq_1')
        self.connect('fc.Fl_O:stat:P', 'nozz.Ps_exhaust')

        pyc.connect_flow(self, 'fc.Fl_O', 'inlet.Fl_I', connect_w=False)
        pyc.connect_flow(self, 'inlet.Fl_O', 'fan.Fl_I')
        pyc.connect_flow(self, 'fan.Fl_O', 'splitter.Fl_I')
        pyc.connect_flow(self, 'splitter.Fl_O1', 'hpc.Fl_I')
        pyc.connect_flow(self, 'hpc.Fl_O', 'bld3.Fl_I')
        pyc.connect_flow(self, 'bld3.Fl_O', 'burner.Fl_I')
        pyc.connect_flow(self, 'burner.Fl_O', 'duct4.Fl_I') 
        pyc.connect_flow(self, 'duct4.Fl_O', 'hpt.Fl_I')
        pyc.connect_flow(self, 'hpt.Fl_O', 'duct45.Fl_I')
        pyc.connect_flow(self, 'duct45.Fl_O', 'lpt.Fl_I')
        pyc.connect_flow(self, 'lpt.Fl_O', 'core_duct.Fl_I')

        pyc.connect_flow(self, 'splitter.Fl_O2', 'byp_duct.Fl_I')
        
        pyc.connect_flow(self, 'core_duct.Fl_O', 'mixer.Fl_I1')
        pyc.connect_flow(self, 'byp_duct.Fl_O', 'mixer.Fl_I2')
        
        pyc.connect_flow(self, 'mixer.Fl_O', 'aug_duct.Fl_I')
        pyc.connect_flow(self, 'aug_duct.Fl_O', 'afterburner.Fl_I')
        pyc.connect_flow(self, 'afterburner.Fl_O', 'nozz.Fl_I')

        pyc.connect_flow(self, 'hpc.cool1', 'lpt.cool1', connect_stat=False)
        pyc.connect_flow(self, 'hpc.cool2', 'lpt.cool2', connect_stat=False)
        pyc.connect_flow(self, 'bld3.cool3', 'hpt.cool3', connect_stat=False)
        pyc.connect_flow(self, 'bld3.cool4', 'hpt.cool4', connect_stat=False)


        balance = self.add_subsystem('balance', om.BalanceComp())
        if design:
            balance.add_balance('W', units='lbm/s', eq_units='lbf')
            self.connect('balance.W', 'inlet.Fl_I:stat:W')
            self.connect('perf.Fn', 'balance.lhs:W')
            
            balance.add_balance('fan_PR', eq_units=None, lower=0.1, val=4)
            self.connect('balance.fan_PR', 'fan.PR')
            self.connect('mixer.ER', 'balance.lhs:fan_PR') 
            
            balance.add_balance('FAR', eq_units='degR', lower=1e-4, val=.017)
            self.connect('balance.FAR', 'burner.Fl_I:FAR')
            self.connect('burner.Fl_O:tot:T', 'balance.lhs:FAR')
            
            balance.add_balance('FAR_AB', eq_units='degR', lower=1e-4, val=0.2)
            self.connect('balance.FAR_AB', 'afterburner.Fl_I:FAR')
            self.connect('afterburner.Fl_O:tot:T', 'balance.lhs:FAR_AB')
            
            balance.add_balance('hpc_PR', lower=1.001, upper=28)
            self.connect('balance.hpc_PR', 'hpc.PR')
            self.connect('perf.OPR', 'balance.lhs:hpc_PR')
            
            balance.add_balance('lpt_PR', val=1.5, lower=1.001, upper=8,
                                eq_units='hp', use_mult=True, mult_val=-1)
            self.connect('balance.lpt_PR', 'lpt.PR')
            self.connect('lp_shaft.pwr_in_real', 'balance.lhs:lpt_PR')
            self.connect('lp_shaft.pwr_out_real', 'balance.rhs:lpt_PR')

            balance.add_balance('hpt_PR', val=1.5, lower=1.001, upper=8,
                                eq_units='hp', use_mult=True, mult_val=-1)
            self.connect('balance.hpt_PR', 'hpt.PR')
            self.connect('hp_shaft.pwr_in_real', 'balance.lhs:hpt_PR')
            self.connect('hp_shaft.pwr_out_real', 'balance.rhs:hpt_PR')
            
            order_add = []

        else:

            balance.add_balance('FAR', val=0.025, lower=1e-4, upper=0.06,eq_units='degR')
            self.connect('balance.FAR', 'burner.Fl_I:FAR')
            self.connect('burner.Fl_O:tot:T', 'balance.lhs:FAR')

            balance.add_balance('W', units='lbm/s', lower=10., upper=1000., rhs_val=2.2)
            self.connect('balance.W', 'inlet.Fl_I:stat:W')
            self.connect('fan.map.RlineMap', 'balance.lhs:W')

            balance.add_balance('FAR_AB', eq_units='degR', lower=1e-4, val=0.025)
            self.connect('balance.FAR_AB', 'afterburner.Fl_I:FAR')
            self.connect('afterburner.Fl_O:tot:T', 'balance.lhs:FAR_AB')

            #balance.add_balance('BPR', lower=0.3, upper=1.2, eq_units='inch**2')
            #self.connect('balance.BPR', 'splitter.BPR')
            #self.connect('mixer.Fl_I1_calc:stat:area', 'balance.lhs:BPR')            

            balance.add_balance('BPR', lower=0.3, upper=1.2)
            self.connect('balance.BPR', 'splitter.BPR')
            self.connect('mixer.ER', 'balance.lhs:BPR')  

            balance.add_balance('lp_Nmech', val=1.5, units='rpm', lower=500., eq_units='hp', use_mult=True, mult_val=-1)
            self.connect('balance.lp_Nmech', 'LP_Nmech')
            self.connect('lp_shaft.pwr_in_real', 'balance.lhs:lp_Nmech')
            self.connect('lp_shaft.pwr_out_real', 'balance.rhs:lp_Nmech')

            balance.add_balance('hp_Nmech', val=1.5, units='rpm', lower=500., eq_units='hp', use_mult=True, mult_val=-1)
            self.connect('balance.hp_Nmech', 'HP_Nmech')
            self.connect('hp_shaft.pwr_in_real', 'balance.lhs:hp_Nmech')
            self.connect('hp_shaft.pwr_out_real', 'balance.rhs:hp_Nmech')
            
            order_add = []

            

        if cooling:
            self.add_subsystem('hpt_cooling', pyc.TurbineCooling(n_stages=2, thermo_data=pyc.species_data.janaf, T_metal=2800.))
            self.add_subsystem('hpt_chargable', pyc.CombineCooling(n_ins=3))
            
            pyc.connect_flow(self, 'bld3.cool3', 'hpt_cooling.Fl_cool', connect_stat=False)
            pyc.connect_flow(self, 'burner.Fl_O', 'hpt_cooling.Fl_turb_I')
            pyc.connect_flow(self, 'hpt.Fl_O', 'hpt_cooling.Fl_turb_O')
            
            self.connect('hpt_cooling.row_1.W_cool', 'hpt_chargable.W_1')
            self.connect('hpt_cooling.row_2.W_cool', 'hpt_chargable.W_2')
            self.connect('hpt_cooling.row_3.W_cool', 'hpt_chargable.W_3')
            self.connect('hpt.power', 'hpt_cooling.turb_pwr')
            
            balance.add_balance('hpt_nochrg_cool_frac', val=0.06366, lower=0.01, upper=0.2, eq_units='lbm/s')
            self.connect('balance.hpt_nochrg_cool_frac', 'bld3.cool3:frac_W')
            self.connect('bld3.cool3:stat:W', 'balance.lhs:hpt_nochrg_cool_frac')
            self.connect('hpt_cooling.row_0.W_cool', 'balance.rhs:hpt_nochrg_cool_frac')
            
            balance.add_balance('hpt_chrg_cool_frac', val=0.07037, lower=0.01, upper=0.2, eq_units='lbm/s')
            self.connect('balance.hpt_chrg_cool_frac', 'bld3.cool4:frac_W')
            self.connect('bld3.cool4:stat:W', 'balance.lhs:hpt_chrg_cool_frac')
            self.connect('hpt_chargable.W_cool', 'balance.rhs:hpt_chrg_cool_frac')
            
            order_add = ['hpt_cooling', 'hpt_chargable']

        main_order = ['fc', 'inlet', 'fan', 'splitter', 'hpc', 'bld3', 'burner', 'duct4', 'hpt', 'duct45',
                            'lpt', 'core_duct', 'byp_duct', 'mixer', 'aug_duct', 'afterburner', 'nozz', 'lp_shaft', 'hp_shaft', 'perf']
        
        self.set_order(main_order + order_add + ['balance'])
        
        newton = self.nonlinear_solver = om.NewtonSolver()
        newton.options['atol'] = 1e-8
        newton.options['rtol'] = 1e-8
        newton.options['iprint'] = 2
        newton.options['maxiter'] = 50
        newton.options['solve_subsystems'] = True
        newton.options['max_sub_solves'] = 100
        newton.options['reraise_child_analysiserror'] = False
        # ls = newton.linesearch = BoundsEnforceLS()
        ls = newton.linesearch = om.ArmijoGoldsteinLS()
        ls.options['maxiter'] = 5
        ls.options['bound_enforcement'] = 'scalar'
        #ls.options['iprint'] = -1

        self.linear_solver = om.DirectSolver(assemble_jac=True)


def viewer(prob, pt, file=sys.stdout):
    """
    print a report of all the relevant cycle properties
    """

    if pt == 'DESIGN':
        MN = prob['DESIGN.fc.Fl_O:stat:MN']
        LPT_PR = prob['DESIGN.balance.lpt_PR']
        HPT_PR = prob['DESIGN.balance.hpt_PR']
        FAR = prob['DESIGN.balance.FAR']
    else:
        MN = prob[pt+'.fc.Fl_O:stat:MN']
        LPT_PR = prob[pt+'.lpt.PR']
        HPT_PR = prob[pt+'.hpt.PR']
        FAR = prob[pt+'.balance.FAR']

    print(file=file, flush=True)
    print(file=file, flush=True)
    print(file=file, flush=True)
    print("----------------------------------------------------------------------------", file=file, flush=True)
    print("                              POINT:", pt, file=file, flush=True)
    print("----------------------------------------------------------------------------", file=file, flush=True)
    print("                       PERFORMANCE CHARACTERISTICS", file=file, flush=True)
    print("    Mach      Alt       W      Fn      Fg    Fram     OPR     TSFC      BPR ", file=file, flush=True)
    print(" %7.5f  %7.1f %7.3f %7.1f %7.1f %7.1f %7.3f  %7.5f  %7.3f" %(MN, prob[pt+'.fc.alt'],prob[pt+'.inlet.Fl_O:stat:W'],prob[pt+'.perf.Fn'],prob[pt+'.perf.Fg'],prob[pt+'.inlet.F_ram'],prob[pt+'.perf.OPR'],prob[pt+'.perf.TSFC'], prob[pt+'.splitter.BPR']), file=file, flush=True)


    fs_names = ['fc.Fl_O', 'inlet.Fl_O', 'fan.Fl_O', 'splitter.Fl_O1', 'splitter.Fl_O2',
                'hpc.Fl_O', 'bld3.Fl_O', 'burner.Fl_O','duct4.Fl_O', 'hpt.Fl_O',
                'duct45.Fl_O', 'lpt.Fl_O', 'core_duct.Fl_O', 'byp_duct.Fl_O', 'mixer.Fl_O', 'aug_duct.Fl_O', 'afterburner.Fl_O', 'nozz.Fl_O']
    fs_full_names = [f'{pt}.{fs}' for fs in fs_names]
    pyc.print_flow_station(prob, fs_full_names, file=file)

    comp_names = ['fan', 'hpc']
    comp_full_names = [f'{pt}.{c}' for c in comp_names]
    pyc.print_compressor(prob, comp_full_names, file=file)

    burn_names = ['burner', 'afterburner']
    burn_full_names = [f'{pt}.{b}' for b in burn_names]
    pyc.print_burner(prob, burn_full_names, file=file)

    turb_names = ['hpt', 'lpt']
    turb_full_names = [f'{pt}.{t}' for t in turb_names]
    pyc.print_turbine(prob, turb_full_names, file=file)

    noz_names = ['nozz']
    noz_full_names = [f'{pt}.{n}' for n in noz_names]
    pyc.print_nozzle(prob, noz_full_names, file=file)
    
    pyc.print_mixer(prob, [pt+'.mixer'])

    shaft_names = ['hp_shaft', 'lp_shaft']
    shaft_full_names = [f'{pt}.{s}' for s in shaft_names]
    pyc.print_shaft(prob, shaft_full_names, file=file)

    bleed_names = ['hpc', 'bld3']
    bleed_full_names = [f'{pt}.{b}' for b in bleed_names]
    pyc.print_bleed(prob, bleed_full_names, file=file)

if __name__ == "__main__":

    import time

    prob = om.Problem()

    des_vars = prob.model.add_subsystem('des_vars',
                                        om.IndepVarComp(), promotes=["*"])

    # FOR DESIGN
    des_vars.add_output('alt', .01, units='ft'),
    des_vars.add_output('MN', 0.00001),
    des_vars.add_output('T4max', 4000.0, units='degR'),
    des_vars.add_output('Fn_des', 45000, units='lbf'),
    des_vars.add_output('OPR_des', 28.0)
    des_vars.add_output('ABTmax', 4000.0, units='degR')
    #des_vars.add_output('fan_area', 1450.0, units='inch**2')
    #des_vars.add_output('afterburner:FAR', 0.03)
    des_vars.add_output('mix_ER', 1.1)
    
    des_vars.add_output('inlet:ram_recovery', 0.9990),
    #des_vars.add_output('fan:PRdes', 3.3),
    des_vars.add_output('fan:effDes', 0.8948),
    des_vars.add_output('splitter:BPR', 0.56),
    #des_vars.add_output('hpc:PRdes', 8.485),
    des_vars.add_output('hpc:effDes', 0.8707),
    des_vars.add_output('burner:dPqP', 0.0540),
    des_vars.add_output('duct4:dPqP', 0.015)
    des_vars.add_output('hpt:effDes', 0.8888),
    des_vars.add_output('duct45:dPqP', 0.015)
    des_vars.add_output('lpt:effDes', 0.8996),
    des_vars.add_output('core_duct:dPqP', 0.015),
    des_vars.add_output('byp_duct:dPqP', 0.015),
    des_vars.add_output('aug_duct:dPqP', 0.015),
    des_vars.add_output('afterburner:dPqP', 0.03)
    des_vars.add_output('nozz:Cfg', 0.9933),
    des_vars.add_output('lp_shaft:Nmech', 4666.1, units='rpm'),
    des_vars.add_output('hp_shaft:Nmech', 14705.7, units='rpm'),
    des_vars.add_output('hp_shaft:HPX', 250., units='hp'),
    
    #
    #MN Flows
    #
    des_vars.add_output('inlet:MN_out', 0.5),
    des_vars.add_output('fan:MN_out', 0.45),
    des_vars.add_output('splitter:MN_out1', 0.35),
    des_vars.add_output('hpc:MN_out', 0.2),
    des_vars.add_output('bld3:MN_out', 0.1)
    des_vars.add_output('burner:MN_out', 0.3),
    des_vars.add_output('duct4:MN_out', 0.5)
    des_vars.add_output('hpt:MN_out', 0.6),
    des_vars.add_output('duct45:MN_out', 0.5)
    des_vars.add_output('lpt:MN_out', 0.5),
    des_vars.add_output('core_duct:MN_out', 0.6)
    
    des_vars.add_output('splitter:MN_out2', 0.6),
    des_vars.add_output('byp_duct:MN_out', 0.4)
    
    des_vars.add_output('aug_duct:MN_out', 0.2)
    des_vars.add_output('afterburner:MN_out', 0.3)
    #
    #
    #
    
    #Cooling Flow Values
    des_vars.add_output('hpc:cool1:frac_W', 0.050708),
    des_vars.add_output('hpc:cool1:frac_P', 0.5),
    des_vars.add_output('hpc:cool1:frac_work', 0.5),
    des_vars.add_output('hpc:cool2:frac_W', 0.020274),
    des_vars.add_output('hpc:cool2:frac_P', 0.55),
    des_vars.add_output('hpc:cool2:frac_work', 0.5),
    des_vars.add_output('bld3:cool3:frac_W', 0.067214),
    des_vars.add_output('bld3:cool4:frac_W', 0.01256),
    des_vars.add_output('hpc:cust:frac_W', 0.0445),
    des_vars.add_output('hpc:cust:frac_P', 0.5),
    des_vars.add_output('hpc:cust:frac_work', 0.5),
    des_vars.add_output('hpt:cool3:frac_P', 1.0),
    des_vars.add_output('hpt:cool4:frac_P', 0.0),
    des_vars.add_output('lpt:cool1:frac_P', 1.0),
    des_vars.add_output('lpt:cool2:frac_P', 0.0),
    
    # OFF DESIGN
    des_vars.add_output('OD_MN', [0.00001, 0.1, 0.2, 0.4, 0.6, 0.8, 0.8, 1.0, 1.2, 1.3]),    
    des_vars.add_output('OD_alt', [0.00001, 0.0, 0.0, 5000.0, 10000.0, 15000.0, 20000.0, 25000.0, 25000., 25000.], units='ft'),
    des_vars.add_output('OD_Fn_target', [38000, 28000, 23000, 21000], units='lbf'), #8950.0    
    des_vars.add_output('OD_dTs', [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], units='degR')    
    #des_vars.add_output('OD_AB_FAR', [0.0, 0.3, 0.3, 0.3, 0.3, 0.3])
    des_vars.add_output('OD_cust_fracW', [0.0445, 0.0445, 0.0445, 0.0445, 0.0445, 0.0445, 0.0445, 0.0445, 0.0445, 0.0445])
    
    #########################
    # DESIGN CASE
    #########################
    
    prob.model.add_subsystem('DESIGN', LBTF_AB(design=True, cooling=True))

    prob.model.connect('alt', 'DESIGN.fc.alt')
    prob.model.connect('MN', 'DESIGN.fc.MN')
    prob.model.connect('Fn_des', 'DESIGN.balance.rhs:W')
    prob.model.connect('T4max', 'DESIGN.balance.rhs:FAR')
    prob.model.connect('ABTmax', 'DESIGN.balance.rhs:FAR_AB')
    prob.model.connect('OPR_des', 'DESIGN.balance.rhs:hpc_PR')
    #prob.model.connect('fan_area', 'DESIGN.balance.rhs:AB_FAR')
    prob.model.connect('mix_ER', 'DESIGN.balance.rhs:fan_PR')
    #prob.model.connect('mix_ER', 'DESIGN.balance.rhs:BPR')
    
    prob.model.connect('inlet:ram_recovery', 'DESIGN.inlet.ram_recovery')
    prob.model.connect('inlet:MN_out', 'DESIGN.inlet.MN')

    #prob.model.connect('fan:PRdes', 'DESIGN.fan.PR')
    prob.model.connect('fan:effDes', 'DESIGN.fan.eff')
    prob.model.connect('fan:MN_out', 'DESIGN.fan.MN')

    prob.model.connect('splitter:MN_out1', 'DESIGN.splitter.MN1')
    prob.model.connect('splitter:MN_out2', 'DESIGN.splitter.MN2')
    prob.model.connect('splitter:BPR', 'DESIGN.splitter.BPR')

    #prob.model.connect('hpc:PRdes', 'DESIGN.hpc.PR')
    prob.model.connect('hpc:effDes', 'DESIGN.hpc.eff')
    prob.model.connect('hpc:MN_out', 'DESIGN.hpc.MN')

    prob.model.connect('bld3:MN_out', 'DESIGN.bld3.MN')

    prob.model.connect('burner:dPqP', 'DESIGN.burner.dPqP')
    prob.model.connect('burner:MN_out', 'DESIGN.burner.MN')
    
    prob.model.connect('duct4:MN_out', 'DESIGN.duct4.MN')
    prob.model.connect('duct4:dPqP', 'DESIGN.duct4.dPqP')

    prob.model.connect('hpt:effDes', 'DESIGN.hpt.eff')
    prob.model.connect('hpt:MN_out', 'DESIGN.hpt.MN')
    
    prob.model.connect('duct45:MN_out', 'DESIGN.duct45.MN')
    prob.model.connect('duct45:dPqP', 'DESIGN.duct45.dPqP')

    prob.model.connect('lpt:effDes', 'DESIGN.lpt.eff')
    prob.model.connect('lpt:MN_out', 'DESIGN.lpt.MN')
    
    prob.model.connect('core_duct:dPqP', 'DESIGN.core_duct.dPqP')
    prob.model.connect('core_duct:MN_out', 'DESIGN.core_duct.MN')
    
    prob.model.connect('byp_duct:dPqP', 'DESIGN.byp_duct.dPqP')
    prob.model.connect('byp_duct:MN_out', 'DESIGN.byp_duct.MN')   
    
    prob.model.connect('aug_duct:dPqP', 'DESIGN.aug_duct.dPqP')
    prob.model.connect('aug_duct:MN_out', 'DESIGN.aug_duct.MN')
    
    prob.model.connect('afterburner:dPqP', 'DESIGN.afterburner.dPqP')
    prob.model.connect('afterburner:MN_out', 'DESIGN.afterburner.MN')
    #prob.model.connect('afterburner:FAR', 'DESIGN.afterburner.Fl_I:FAR')

    prob.model.connect('nozz:Cfg', 'DESIGN.nozz.Cfg')
        
    prob.model.connect('lp_shaft:Nmech', 'DESIGN.LP_Nmech')
    prob.model.connect('hp_shaft:Nmech', 'DESIGN.HP_Nmech')
    prob.model.connect('hp_shaft:HPX', 'DESIGN.hp_shaft.HPX')

    prob.model.connect('hpc:cool1:frac_W', 'DESIGN.hpc.cool1:frac_W')
    prob.model.connect('hpc:cool1:frac_P', 'DESIGN.hpc.cool1:frac_P')
    prob.model.connect('hpc:cool1:frac_work', 'DESIGN.hpc.cool1:frac_work')
    prob.model.connect('hpc:cool2:frac_W', 'DESIGN.hpc.cool2:frac_W')
    prob.model.connect('hpc:cool2:frac_P', 'DESIGN.hpc.cool2:frac_P')
    prob.model.connect('hpc:cool2:frac_work', 'DESIGN.hpc.cool2:frac_work')
    #prob.model.connect('bld3:cool3:frac_W', 'DESIGN.bld3.cool3:frac_W')
    #prob.model.connect('bld3:cool4:frac_W', 'DESIGN.bld3.cool4:frac_W')
    prob.model.connect('hpc:cust:frac_W', 'DESIGN.hpc.cust:frac_W')
    prob.model.connect('hpc:cust:frac_P', 'DESIGN.hpc.cust:frac_P')
    prob.model.connect('hpc:cust:frac_work', 'DESIGN.hpc.cust:frac_work')
    prob.model.connect('hpt:cool3:frac_P', 'DESIGN.hpt.cool3:frac_P')
    prob.model.connect('hpt:cool4:frac_P', 'DESIGN.hpt.cool4:frac_P')
    prob.model.connect('lpt:cool1:frac_P', 'DESIGN.lpt.cool1:frac_P')
    prob.model.connect('lpt:cool2:frac_P', 'DESIGN.lpt.cool2:frac_P')

    # OFF DESIGN CASES
    #pts = []
    pts = ['OD1']#,'OD2','OD3','OD4', 'OD5', 'OD6', 'OD7', 'OD8', 'OD9', 'OD10']

    for i_OD, pt in enumerate(pts):
        ODpt = prob.model.add_subsystem(pt, LBTF_AB(design=False, cooling=True))

        prob.model.connect('OD_alt', pt+'.fc.alt', src_indices=i_OD)
        prob.model.connect('OD_MN', pt+'.fc.MN', src_indices=i_OD)
        prob.model.connect('T4max', pt+'.balance.rhs:FAR')
        prob.model.connect('OD_dTs', pt+'.fc.dTs', src_indices=i_OD)
        prob.model.connect('OD_cust_fracW', pt+'.hpc.cust:frac_W', src_indices=i_OD)
        prob.model.connect('ABTmax', pt+'.balance.rhs:FAR_AB')
        prob.model.connect('mix_ER', pt+'.balance.rhs:BPR')
        #prob.model.connect('OD_AB_FAR', pt+'.afterburner.Fl_I:FAR', src_indices=i_OD)

        #prob.model.connect('DESIGN.inlet.Fl_O:stat:W', pt+'.inlet.Fl_I:stat:W')
        prob.model.connect('inlet:ram_recovery', pt+'.inlet.ram_recovery')
        #prob.model.connect('splitter:BPR', pt+'.splitter.BPR')
        prob.model.connect('burner:dPqP', pt+'.burner.dPqP')
        prob.model.connect('nozz:Cfg', pt+'.nozz.Cfg')
        prob.model.connect('hp_shaft:HPX', pt+'.hp_shaft.HPX')
        prob.model.connect('duct4:dPqP', pt+'.duct4.dPqP')
        prob.model.connect('duct45:dPqP', pt+'.duct45.dPqP')
        prob.model.connect('core_duct:dPqP', pt+'.core_duct.dPqP')
        prob.model.connect('byp_duct:dPqP', pt+'.byp_duct.dPqP')
        prob.model.connect('aug_duct:dPqP', pt+'.aug_duct.dPqP')
        prob.model.connect('afterburner:dPqP', pt+'.afterburner.dPqP')

        prob.model.connect('hpc:cool1:frac_W', pt+'.hpc.cool1:frac_W')
        prob.model.connect('hpc:cool1:frac_P', pt+'.hpc.cool1:frac_P')
        prob.model.connect('hpc:cool1:frac_work', pt+'.hpc.cool1:frac_work')
        prob.model.connect('hpc:cool2:frac_W', pt+'.hpc.cool2:frac_W')
        prob.model.connect('hpc:cool2:frac_P', pt+'.hpc.cool2:frac_P')
        prob.model.connect('hpc:cool2:frac_work', pt+'.hpc.cool2:frac_work')
        #prob.model.connect('bld3:cool3:frac_W', pt+'.bld3.cool3:frac_W')
        #prob.model.connect('bld3:cool4:frac_W', pt+'.bld3.cool4:frac_W')
        
        # prob.model.connect('hpc:cust:frac_W', pt+'.hpc.cust:frac_W')
        prob.model.connect('hpc:cust:frac_P', pt+'.hpc.cust:frac_P')
        prob.model.connect('hpc:cust:frac_work', pt+'.hpc.cust:frac_work')
        prob.model.connect('hpt:cool3:frac_P', pt+'.hpt.cool3:frac_P')
        prob.model.connect('hpt:cool4:frac_P', pt+'.hpt.cool4:frac_P')
        prob.model.connect('lpt:cool1:frac_P', pt+'.lpt.cool1:frac_P')
        prob.model.connect('lpt:cool2:frac_P', pt+'.lpt.cool2:frac_P')

        prob.model.connect('DESIGN.fan.s_PR', pt+'.fan.s_PR')
        prob.model.connect('DESIGN.fan.s_Wc', pt+'.fan.s_Wc')
        prob.model.connect('DESIGN.fan.s_eff', pt+'.fan.s_eff')
        prob.model.connect('DESIGN.fan.s_Nc', pt+'.fan.s_Nc')
        
        prob.model.connect('DESIGN.hpc.s_PR', pt+'.hpc.s_PR')
        prob.model.connect('DESIGN.hpc.s_Wc', pt+'.hpc.s_Wc')
        prob.model.connect('DESIGN.hpc.s_eff', pt+'.hpc.s_eff')
        prob.model.connect('DESIGN.hpc.s_Nc', pt+'.hpc.s_Nc')
        
        prob.model.connect('DESIGN.hpt.s_PR', pt+'.hpt.s_PR')
        prob.model.connect('DESIGN.hpt.s_Wp', pt+'.hpt.s_Wp')
        prob.model.connect('DESIGN.hpt.s_eff', pt+'.hpt.s_eff')
        prob.model.connect('DESIGN.hpt.s_Np', pt+'.hpt.s_Np')
        
        prob.model.connect('DESIGN.lpt.s_PR', pt+'.lpt.s_PR')
        prob.model.connect('DESIGN.lpt.s_Wp', pt+'.lpt.s_Wp')
        prob.model.connect('DESIGN.lpt.s_eff', pt+'.lpt.s_eff')
        prob.model.connect('DESIGN.lpt.s_Np', pt+'.lpt.s_Np')

        #prob.model.connect('OD_Fn_target',pt+'.balance.rhs:W', src_indices=i_OD)
        #prob.model.connect('DESIGN.byp_duct.Fl_O:stat:area',pt+'.balance.rhs:BPR')

        prob.model.connect('DESIGN.inlet.Fl_O:stat:area', pt+'.inlet.area')
        prob.model.connect('DESIGN.fan.Fl_O:stat:area', pt+'.fan.area')
        prob.model.connect('DESIGN.splitter.Fl_O1:stat:area', pt+'.splitter.area1')
        prob.model.connect('DESIGN.splitter.Fl_O2:stat:area', pt+'.splitter.area2')
        prob.model.connect('DESIGN.hpc.Fl_O:stat:area', pt+'.hpc.area')
        prob.model.connect('DESIGN.bld3.Fl_O:stat:area', pt+'.bld3.area')
        prob.model.connect('DESIGN.burner.Fl_O:stat:area', pt+'.burner.area')
        prob.model.connect('DESIGN.duct4.Fl_O:stat:area', pt+'.duct4.area')
        prob.model.connect('DESIGN.hpt.Fl_O:stat:area', pt+'.hpt.area')
        prob.model.connect('DESIGN.duct45.Fl_O:stat:area', pt+'.duct45.area')
        prob.model.connect('DESIGN.lpt.Fl_O:stat:area', pt+'.lpt.area')
        prob.model.connect('DESIGN.core_duct.Fl_O:stat:area', pt+'.core_duct.area')
        prob.model.connect('DESIGN.byp_duct.Fl_O:stat:area', pt+'.byp_duct.area')
        prob.model.connect('DESIGN.mixer.Fl_O:stat:area', pt+'.mixer.area')
        prob.model.connect('DESIGN.mixer.Fl_I1_calc:stat:area', pt+'.mixer.Fl_I1_stat_calc.area')
        
        #prob.model.connect('DESIGN.mixer.Fl_I1_calc:stat:area', pt+'.balance.rhs:BPR')
        
        prob.model.connect('DESIGN.aug_duct.Fl_O:stat:area', pt+'.aug_duct.area')
        prob.model.connect('DESIGN.afterburner.Fl_O:stat:area', pt+'.afterburner.area')

    prob.setup(check=False)

    # initial guesses
    prob['DESIGN.balance.FAR'] = 0.032
    prob['DESIGN.balance.FAR_AB'] = 0.032
    prob['DESIGN.balance.W'] = 250
    #prob['DESIGN.balance.BPR'] = 1.7
    #prob['DESIGN.balance.core_MN'] = .9
    prob['DESIGN.balance.hpc_PR'] = 4
    prob['DESIGN.balance.fan_PR'] = 7
    prob['DESIGN.balance.lpt_PR'] = 1.6
    prob['DESIGN.balance.hpt_PR'] = 2.3
    prob['DESIGN.fc.balance.Pt'] = 5.2
    prob['DESIGN.fc.balance.Tt'] = 440.0
    prob['DESIGN.mixer.balance.P_tot']= 75
    
    FAR_guesses = [.045, .045, .046, .047, .047, .047, .047, .047, .047, .045]
    FAB_AB_guesses = [.035, .035, .035, .035, .035, .035, .035, .035, .035, .035]
    W_guesses = [315, 300, 300, 300, 300, 260, 230, 220, 220, 220]
    lp_Nmech_guesses = [4600, 4600, 4600, 4700, 4700, 4700, 4700, 4700, 4700, 4500]
    hp_Nmech_guesses = [14700, 14700, 14800, 14700, 14700, 14700, 14700, 14700, 14700, 14700]    
    
    for i, pt in enumerate(pts):
        # ADP and TOC guesses
        prob[pt+'.balance.FAR'] = FAR_guesses[i]
        prob[pt+'.balance.W'] = W_guesses[i]
        prob[pt+'.balance.FAR_AB'] = FAB_AB_guesses[i]
        prob[pt+'.balance.BPR'] = .6
        prob[pt+'.balance.lp_Nmech'] = lp_Nmech_guesses[i]
        prob[pt+'.balance.hp_Nmech'] = hp_Nmech_guesses[i]
        prob[pt+'.mixer.balance.P_tot']= 90
        prob[pt+'.fc.balance.Pt'] = 14
        prob[pt+'.fc.balance.Tt'] = 520
        prob[pt+'.lpt.PR'] = 2.1        
        prob[pt+'.hpt.PR'] = 1.96
        #prob[pt+'.fan.map.RlineMap'] = 2.2
        prob[pt+'.hpc.map.RlineMap'] = 2.0

    st = time.time()

    prob.set_solver_print(level=-1)
    prob.set_solver_print(level=2, depth=1)
    prob.run_model()
    prob.model.DESIGN.list_outputs(residuals=True, residuals_tol=1e-2)


    for pt in ['DESIGN']+pts:
        viewer(prob, pt)


    print()
    print("time", time.time() - st)

