import sys

import openmdao.api as om

import pycycle.api as pyc

class TurbojetPrac(om.Group):
    
    def initialize(self):
        self.options.declare('design', default = True, 
                             desc = 'switch between on-design and off-design calculations')
        
    def setup(self):
        
        thermo_spec = pyc.species_data.janaf
        design = self.options['design']

        #engine elements
        self.add_subsystem('fc', pyc.FlightConditions(thermo_data=thermo_spec, 
                                      elements=pyc.AIR_MIX))
        self.add_subsystem('inlet', pyc.Inlet(design=design, thermo_data=thermo_spec,
                                      elements=pyc.AIR_MIX))
        self.add_subsystem('comp', pyc.Compressor(map_data=pyc.AXI5, design=design,
                                    thermo_data=thermo_spec, elements=pyc.AIR_MIX, bleed_names= ['cool1'], map_extrap=True),
                                    promotes_inputs=['Nmech'])
        self.add_subsystem('burner', pyc.Combustor(design=design,thermo_data=thermo_spec,
                                    inflow_elements=pyc.AIR_MIX,
                                    air_fuel_elements=pyc.AIR_FUEL_MIX,
                                    fuel_type='JP-7'))
        self.add_subsystem('turb', pyc.Turbine(map_data=pyc.LPT2269, design=design,
                                    thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX, bleed_names=['cool1'], map_extrap=True),
                                    promotes_inputs=['Nmech'])
        self.add_subsystem('nozz', pyc.Nozzle(nozzType = 'CV', lossCoef='Cv', 
                                    thermo_data=thermo_spec, elements=pyc.AIR_FUEL_MIX))
        self.add_subsystem('shaft', pyc.Shaft(num_ports=2), promotes_inputs=['Nmech'])
        self.add_subsystem('perf', pyc.Performance(num_nozzles=1, num_burners=1))


        #Connect flow stations
        pyc.connect_flow(self, 'fc.Fl_O', 'inlet.Fl_I', connect_w=False)
        pyc.connect_flow(self, 'inlet.Fl_O', 'comp.Fl_I')
        pyc.connect_flow(self, 'comp.Fl_O', 'burner.Fl_I')
        pyc.connect_flow(self, 'burner.Fl_O', 'turb.Fl_I')
        pyc.connect_flow(self, 'turb.Fl_O', 'nozz.Fl_I')
        
        #connect turbomachinery components to shaft
        self.connect('comp.trq', 'shaft.trq_0')
        self.connect('turb.trq', 'shaft.trq_1')
        
        #connect nozzle exhause to freestream static conditions
        self.connect('fc.Fl_O:stat:P', 'nozz.Ps_exhaust')
        
        #Connect outputs to performance element
        self.connect('inlet.Fl_O:tot:P', 'perf.Pt2')
        self.connect('comp.Fl_O:tot:P', 'perf.Pt3')
        self.connect('burner.Wfuel', 'perf.Wfuel_0')
        self.connect('inlet.F_ram', 'perf.ram_drag')
        self.connect('nozz.Fg', 'perf.Fg_0')
        
        pyc.connect_flow(self, 'comp.cool1', 'turb.cool1', connect_stat=False)
        
        #Add balances for design and off-design
        balance = self.add_subsystem('balance', om.BalanceComp())
        if design:
            
            balance.add_balance('W', units='lbm/s', eq_units='lbf')
            self.connect('balance.W', 'inlet.Fl_I:stat:W')
            self.connect('perf.Fn', 'balance.lhs:W')
            
            balance.add_balance('FAR', eq_units='degR', lower=1e-4, val=.017)
            self.connect('balance.FAR', 'burner.Fl_I:FAR')
            self.connect('turb.Fl_O:tot:T', 'balance.lhs:FAR')
            
            balance.add_balance('turb_PR', val=3.0, lower=1.001, upper=8, eq_units='hp', rhs_val=0.)
            self.connect('balance.turb_PR', 'turb.PR')
            self.connect('shaft.pwr_net', 'balance.lhs:turb_PR')
            
        else:
            
            balance.add_balance('FAR', eq_units='lbf', lower=1e-4, val=.3)
            self.connect('balance.FAR', 'burner.Fl_I:FAR')
            self.connect('perf.Fn', 'balance.lhs:FAR')
            
            balance.add_balance('Nmech', val=8000, units='rpm', lower=500, eq_units='hp', rhs_val=0.)
            self.connect('balance.Nmech', 'Nmech')
            self.connect('shaft.pwr_net', 'balance.lhs:Nmech')            
            
            balance.add_balance('W', val=120., units='lbm/s', eq_units='inch**2')
            self.connect('balance.W', 'inlet.Fl_I:stat:W')
            self.connect('nozz.Throat:stat:area', 'balance.lhs:W')
            
            #balance.add_balance('frac_W', val=0.05, lower=0.0001, eq_units='degR')
            #self.connect('balance.frac_W', 'comp.cool1:frac_W')
            #self.connect('turb.Fl_O:tot:T', 'balance.lhs:frac_W')
            
        #Setup solver to converge engine
        self.set_order(['balance', 'fc', 'inlet', 'comp', 'burner', 'turb', 'nozz', 'shaft', 'perf'])
        
        newton = self.nonlinear_solver = om.NewtonSolver()
        newton.options['atol'] = 1e-6
        newton.options['rtol'] = 1e-6
        newton.options['iprint'] = 2
        newton.options['maxiter'] = 50
        newton.options['solve_subsystems'] = True
        newton.options['max_sub_solves'] = 100
        newton.options['reraise_child_analysiserror'] = False

        # newton.linesearch = om.BoundsEnforceLS()
        newton.linesearch = om.ArmijoGoldsteinLS()
        # newton.linesearch.options['c'] = .0001
        newton.linesearch.options['bound_enforcement'] = 'scalar'
        newton.linesearch.options['iprint'] = -1       
        
        self.linear_solver = om.DirectSolver(assemble_jac=True)
        
def viewer(prob, pt, file=sys.stdout):
    """
    print a report of all the relevant cycle properties
    """

    print(file=file, flush=True)
    print(file=file, flush=True)
    print(file=file, flush=True)
    print("----------------------------------------------------------------------------", file=file, flush=True)
    print("                              POINT:", pt, file=file, flush=True)
    print("----------------------------------------------------------------------------", file=file, flush=True)
    print("                       PERFORMANCE CHARACTERISTICS", file=file, flush=True)
    print("    Mach      Alt       W      Fn      Fg    Fram     OPR     TSFC", file=file, flush=True)
    print(" %7.5f  %7.1f %7.3f %7.1f %7.1f %7.1f %7.3f  %7.5f " \
              %(prob[pt+'.fc.Fl_O:stat:MN'], prob[pt+'.fc.alt'],prob[pt+'.inlet.Fl_O:stat:W'], \
                prob[pt+'.perf.Fn'],prob[pt+'.perf.Fg'],prob[pt+'.inlet.F_ram'],prob[pt+'.perf.OPR'], \
                prob[pt+'.perf.TSFC']), file=file, flush=True)


    fs_names = ['fc.Fl_O', 'inlet.Fl_O', 'comp.Fl_O', 'burner.Fl_O',
                'turb.Fl_O', 'nozz.Fl_O']
    
    fs_full_names = [f'{pt}.{fs}' for fs in fs_names]
    pyc.print_flow_station(prob, fs_full_names, file=file)

    comp_names = ['comp']
    comp_full_names = [f'{pt}.{c}' for c in comp_names]
    pyc.print_compressor(prob, comp_full_names, file=file)

    pyc.print_burner(prob, [f'{pt}.burner'])

    turb_names = ['turb']
    turb_full_names = [f'{pt}.{t}' for t in turb_names]
    pyc.print_turbine(prob, turb_full_names, file=file)

    noz_names = ['nozz']
    noz_full_names = [f'{pt}.{n}' for n in noz_names]
    pyc.print_nozzle(prob, noz_full_names, file=file)

    shaft_names = ['shaft']
    shaft_full_names = [f'{pt}.{s}' for s in shaft_names]
    pyc.print_shaft(prob, shaft_full_names, file=file)

    bleed_names = ['comp']
    bleed_full_names = [f'{pt}.{b}' for b in bleed_names]
    pyc.print_bleed(prob, bleed_full_names, file=file)
        
        
if __name__ == "__main__":

    import time
    from openmdao.api import Problem, IndepVarComp
    from openmdao.utils.units import convert_units as cu
    
    prob = om.Problem()

    des_vars = prob.model.add_subsystem('des_vars',
                                        om.IndepVarComp(), promotes=["*"])

    # FOR DESIGN
    des_vars.add_output('alt', 0.0, units='ft'),
    des_vars.add_output('MN', 0.000001),
    des_vars.add_output('T4max', 2300.0, units='degR'),
    des_vars.add_output('Fn_des', 40000.0, units='lbf'),

    des_vars.add_output('comp:PRdes', 13.5),
    des_vars.add_output('comp:effDes', 0.83),
    des_vars.add_output('burner:dPqP', 0.03),
    des_vars.add_output('turb:effDes', 0.86),
    des_vars.add_output('nozz:Cv', 0.99),
    des_vars.add_output('shaft:Nmech', 8070.0, units='rpm'),

    des_vars.add_output('inlet:MN_out', 0.60),
    des_vars.add_output('comp:MN_out', 0.20),
    des_vars.add_output('burner:MN_out', 0.20),
    des_vars.add_output('tbld:MN_out', 0.20),
    des_vars.add_output('turb:MN_out', 0.40),
    
    des_vars.add_output('comp:cool1:frac_W', 0.05),
    des_vars.add_output('comp:cool1:frac_P', 0.5),
    des_vars.add_output('comp:cool1:frac_work', 0.5),
    des_vars.add_output('turb:cool1:frac_P', 1.0),




    #
    # Off-design (point 1) inputs
    #
    des_vars.add_output('OD1_MN', 0.2),
    des_vars.add_output('OD1_alt', 0.0, units='ft'),
    des_vars.add_output('OD1_Fn', 11000, units='lbf'),
    
    #
    # Off-design (point 2) inputs
    #
    des_vars.add_output('OD2_MN', 0.5),
    des_vars.add_output('OD2_alt', 3000, units='ft'),
    des_vars.add_output('OD2_Fn', 7000, units='lbf'),

    #
    # Off-design (point 3) inputs
    #
    des_vars.add_output('OD3_MN', .7),
    des_vars.add_output('OD3_alt', 30000, units='ft'),
    des_vars.add_output('OD3_Fn', 5000, units='lbf'),

    #
    # Off-design (point 4) inputs
    #
    des_vars.add_output('OD4_MN', .9),
    des_vars.add_output('OD4_alt', 30000, units='ft'),
    des_vars.add_output('OD4_Fn', 3000, units='lbf'),
    #
    #
    #
    #des_vars.add_output('OD_W', 120, units='lbm/s')
    
    
    
    # DESIGN CASE
    prob.model.add_subsystem('DESIGN', TurbojetPrac())

    prob.model.connect('alt', 'DESIGN.fc.alt')
    prob.model.connect('MN', 'DESIGN.fc.MN')
    prob.model.connect('T4max', 'DESIGN.balance.rhs:FAR')
    prob.model.connect('Fn_des', 'DESIGN.balance.rhs:W')
    
    prob.model.connect('comp:PRdes', 'DESIGN.comp.PR')
    prob.model.connect('comp:effDes', 'DESIGN.comp.eff')
    prob.model.connect('burner:dPqP', 'DESIGN.burner.dPqP')
    prob.model.connect('turb:effDes', 'DESIGN.turb.eff')
    prob.model.connect('nozz:Cv', 'DESIGN.nozz.Cv')
    prob.model.connect('shaft:Nmech', 'DESIGN.Nmech')
    
    prob.model.connect('inlet:MN_out', 'DESIGN.inlet.MN')
    prob.model.connect('comp:MN_out', 'DESIGN.comp.MN')
    prob.model.connect('burner:MN_out', 'DESIGN.burner.MN')
    prob.model.connect('turb:MN_out', 'DESIGN.turb.MN')
    
    prob.model.connect('comp:cool1:frac_W', 'DESIGN.comp.cool1:frac_W')
    prob.model.connect('comp:cool1:frac_P', 'DESIGN.comp.cool1:frac_P')
    prob.model.connect('comp:cool1:frac_work', 'DESIGN.comp.cool1:frac_work')
    prob.model.connect('turb:cool1:frac_P', 'DESIGN.turb.cool1:frac_P')
    
    #Connect off-design and required design inputs to model
    #pts = ['OD1', 'OD2', 'OD3', 'OD4']
    pts = []
    
    for pt in pts:
        
        prob.model.add_subsystem(pt, TurbojetPrac(design=False))
        
        prob.model.connect('burner:dPqP', pt+'.burner.dPqP')
        prob.model.connect('nozz:Cv', pt+'.nozz.Cv')

        prob.model.connect(pt+'_alt', pt+'.fc.alt')
        prob.model.connect(pt+'_MN', pt+'.fc.MN')
        prob.model.connect(pt+'_Fn', pt+'.balance.rhs:FAR')
        #prob.model.connect('OD_W', pt+'.inlet.Fl_I:stat:W')

        prob.model.connect('DESIGN.comp.s_PR', pt+'.comp.s_PR')
        prob.model.connect('DESIGN.comp.s_Wc', pt+'.comp.s_Wc')
        prob.model.connect('DESIGN.comp.s_eff', pt+'.comp.s_eff')
        prob.model.connect('DESIGN.comp.s_Nc', pt+'.comp.s_Nc')

        prob.model.connect('DESIGN.turb.s_PR', pt+'.turb.s_PR')
        prob.model.connect('DESIGN.turb.s_Wp', pt+'.turb.s_Wp')
        prob.model.connect('DESIGN.turb.s_eff', pt+'.turb.s_eff')
        prob.model.connect('DESIGN.turb.s_Np', pt+'.turb.s_Np')

        prob.model.connect('DESIGN.inlet.Fl_O:stat:area', pt+'.inlet.area')
        prob.model.connect('DESIGN.comp.Fl_O:stat:area', pt+'.comp.area')
        prob.model.connect('DESIGN.burner.Fl_O:stat:area', pt+'.burner.area')
        prob.model.connect('DESIGN.turb.Fl_O:stat:area', pt+'.turb.area')
        
        #prob.model.connect('T4max', pt+'.balance.rhs:frac_W')
        
        prob.model.connect('comp:cool1:frac_W', pt+'.comp.cool1:frac_W')
        prob.model.connect('comp:cool1:frac_W', pt+'.comp.cool1:frac_P')
        prob.model.connect('comp:cool1:frac_work', pt+'.comp.cool1:frac_work')
        prob.model.connect('turb:cool1:frac_P', pt+'.turb.cool1:frac_P')
        
        #prob.model.connect(pt+'_pwr', pt+'.balance.rhs:FAR')
        prob.model.connect('DESIGN.nozz.Throat:stat:area', pt+'.balance.rhs:W')

    prob.setup(check=True)

    # initial guesses
    prob['DESIGN.balance.FAR'] = 0.0175506829934
    prob['DESIGN.balance.W'] = 120.
    prob['DESIGN.balance.turb_PR'] = 4

    
    for pt in pts:
        prob[pt+'.balance.W'] = 120.
        prob[pt+'.balance.FAR'] = 0.0175506829934
        prob[pt+'.balance.Nmech'] = 8000.
        #prob[pt+'.turb.PR'] = 3.8768
        #prob[pt+'.balance.frac_W'] = 0.08
    
    st = time.time()

    prob.set_solver_print(level=-1)
    prob.set_solver_print(level=2, depth=1)
    prob.run_model()
    
    for pt in ['DESIGN']+pts:
        viewer(prob, pt)

    print()
    print("time", time.time() - st)
